package com.smartlib.dto;

import lombok.Data;

@Data
public class ResponseDTO<T> {
    private Integer code;
    private String message;
    private T data;
    private Long timestamp;

    public ResponseDTO() {
        this.timestamp = System.currentTimeMillis();
    }

    public ResponseDTO(Integer code, String message, T data) {
        this.code = code;
        this.message = message;
        this.data = data;
        this.timestamp = System.currentTimeMillis();
    }

    public static <T> ResponseDTO<T> success(T data) {
        return new ResponseDTO<>(200, "success", data);
    }

    public static <T> ResponseDTO<T> error(int i, String message) {
        return new ResponseDTO<>(500, message, null);
    }

   
}