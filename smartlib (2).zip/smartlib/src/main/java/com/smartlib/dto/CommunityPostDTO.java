package com.smartlib.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import java.util.List;

@Data
public class CommunityPostDTO {
    private Integer id;
    private String title;
    private String content;

    @JsonProperty("author")
    private AuthorDTO author;

    private String category;

    @JsonProperty("views")
    private Integer views;

    @JsonProperty("comments")
    private Integer comments;

    @JsonProperty("likes")
    private Integer likes;

    @JsonProperty("collects")
    private Integer collects;

    @JsonProperty("liked")
    private Boolean liked;

    @JsonProperty("collected")
    private Boolean collected;

    @JsonProperty("images")
    private List<String> images;

    @JsonProperty("tags")
    private List<String> tags;

    @JsonProperty("createdAt")
    private String createdAt;

    @Data
    public static class AuthorDTO {
        private Integer id;
        private String name;
        private String avatar;
    }
}