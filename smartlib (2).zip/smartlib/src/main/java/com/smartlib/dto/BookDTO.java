package com.smartlib.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import java.util.List;

@Data
public class BookDTO {
    private Integer id;
    private String title;
    private String author;
    private String category;

    @JsonProperty("rating")
    private Double rating = 0.0;

    @JsonProperty("borrowCount")
    private Integer borrowCount = 0;

    private Integer stock = 1;
    private Boolean available = true;

    @JsonProperty("isNew")
    private Boolean isNew = false;

    private String cover;

    // 详情页字段
    private String isbn;
    private String publisher;
    private String description;
    private List<String> tags;

    // 推荐页字段
    @JsonProperty("recommendReason")
    private String recommendReason;

    @JsonProperty("isHot")
    private Boolean isHot = false;

    private Boolean liked = false;
}