package com.smartlib.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class UserDTO {
    private Integer id;
    private String username;
    private String email;
    private String avatar;

    @JsonProperty("student_id")
    private String studentId;

    private String phone;

    @JsonProperty("borrow_count")
    private Integer borrowCount = 0;

    @JsonProperty("current_borrow")
    private Integer currentBorrow = 0;

    private Integer score = 0;

    @JsonProperty("consecutive_days")
    private Integer consecutiveDays = 0;
}