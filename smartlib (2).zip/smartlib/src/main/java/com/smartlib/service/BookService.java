package com.smartlib.service;

import com.smartlib.dto.BookDTO;
import com.smartlib.entity.Book;
import com.smartlib.repository.BookRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class BookService {

    @Autowired
    private BookRepository bookRepository;

    public List<BookDTO> getBooks(Integer page, Integer size, String keyword, String category) {
        List<Book> books;

        if (keyword != null && !keyword.trim().isEmpty()) {
            books = bookRepository.searchByKeyword(keyword.trim());
        } else if (category != null && !category.trim().isEmpty()) {
            books = bookRepository.findByCategory(category.trim());
        } else {
            books = bookRepository.findAll();
        }

        // 简单分页
        if (page != null && size != null) {
            int start = (page - 1) * size;
            int end = Math.min(start + size, books.size());
            if (start < books.size()) {
                books = books.subList(start, end);
            } else {
                books = new ArrayList<>();
            }
        }

        return books.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public BookDTO getBookById(Integer bookId) {
        Book book = bookRepository.findById(bookId)
                .orElseThrow(() -> new RuntimeException("图书不存在"));
        return convertToDTO(book);
    }

    public List<BookDTO> getHotBooks() {
        List<Book> books = bookRepository.findByIsHot(1);
        return books.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<BookDTO> getNewBooks() {
        List<Book> books = bookRepository.findByIsNew(1);
        return books.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<BookDTO> getRecommendedBooks(String algorithm) {
        List<Book> books = new ArrayList<>();

        switch (algorithm) {
            case "collaborative":
                books = bookRepository.findByIsHot(1);
                break;
            case "content":
                books = bookRepository.findByCategory("前端开发");
                break;
            case "popular":
                books = bookRepository.findAll();
                break;
            default:
                books = bookRepository.findByIsNew(1);
        }

        return books.stream()
                .map(book -> {
                    BookDTO dto = convertToDTO(book);
                    dto.setRecommendReason(getRecommendReason(algorithm));
                    dto.setIsHot(book.getIsHot() == 1);
                    return dto;
                })
                .collect(Collectors.toList());
    }

    private BookDTO convertToDTO(Book book) {
        BookDTO dto = new BookDTO();
        BeanUtils.copyProperties(book, dto);
        dto.setCover(book.getCover());
        dto.setRating(book.getRating());
        dto.setBorrowCount(book.getBorrowCount());
        dto.setAvailable(book.getAvailable() == 1);
        dto.setIsNew(book.getIsNew() == 1);
        dto.setIsHot(book.getIsHot() == 1);
        return dto;
    }

    private String getRecommendReason(String algorithm) {
        switch (algorithm) {
            case "collaborative": return "根据相似用户推荐";
            case "content": return "基于内容相似推荐";
            case "popular": return "热门图书推荐";
            default: return "为您推荐";
        }
    }
}