package com.smartlib.service;

import com.smartlib.entity.BorrowRecord;
import com.smartlib.repository.BorrowRecordRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class UserService {

    @Autowired
    private BorrowRecordRepository borrowRecordRepository;

    public Map<String, Object> getUserStats(Integer userId) {
        List<BorrowRecord> allRecords = borrowRecordRepository.findByUserId(userId);
        List<BorrowRecord> borrowedRecords = borrowRecordRepository.findByUserIdAndStatus(userId, "BORROWED");
        List<BorrowRecord> overdueRecords = borrowRecordRepository.findByUserIdAndStatus(userId, "OVERDUE");

        Map<String, Object> stats = new HashMap<>();
        stats.put("totalBorrowed", allRecords.size());
        stats.put("currentlyBorrowed", borrowedRecords.size());
        stats.put("overdueCount", overdueRecords.size());
        stats.put("favoriteCategory", "前端开发"); // 简化

        return stats;
    }
}