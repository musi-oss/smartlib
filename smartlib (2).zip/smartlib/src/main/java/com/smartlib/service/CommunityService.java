package com.smartlib.service;

import com.smartlib.dto.CommunityPostDTO;
import com.smartlib.entity.CommunityPost;
import com.smartlib.repository.CommunityPostRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class CommunityService {

    @Autowired
    private CommunityPostRepository postRepository;

    public List<CommunityPostDTO> getPosts(String category, String sort, String keyword) {
        List<CommunityPost> posts;

        if (category != null && !category.isEmpty()) {
            posts = postRepository.findByCategory(category);
        } else {
            posts = postRepository.findByOrderByCreatedAtDesc();
        }

        // 简单搜索
        if (keyword != null && !keyword.isEmpty()) {
            posts = posts.stream()
                    .filter(post -> post.getTitle().contains(keyword) ||
                            post.getContent().contains(keyword))
                    .collect(Collectors.toList());
        }

        return posts.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public Map<String, Object> createPost(Integer userId, String title, String content,
                                          String category) {
        CommunityPost post = new CommunityPost();
        post.setUserId(userId);
        post.setTitle(title);
        post.setContent(content);
        post.setCategory(category);
        post.setAuthorName("用户" + userId);

        postRepository.save(post);

        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("message", "发布成功");
        result.put("postId", post.getId());

        return result;
    }

    private CommunityPostDTO convertToDTO(CommunityPost post) {
        CommunityPostDTO dto = new CommunityPostDTO();
        BeanUtils.copyProperties(post, dto);
        dto.setViews(post.getViews());
        dto.setComments(post.getComments());
        dto.setLikes(post.getLikes());
        dto.setCollects(post.getCollects());
        dto.setLiked(post.getLiked() == 1);
        dto.setCollected(post.getCollected() == 1);

        // 设置作者信息
        CommunityPostDTO.AuthorDTO author = new CommunityPostDTO.AuthorDTO();
        author.setId(post.getUserId());
        author.setName(post.getAuthorName());
        author.setAvatar(post.getAuthorAvatar());
        dto.setAuthor(author);

        // 简单处理tags
        if (post.getTags() != null) {
            dto.setTags(Arrays.asList(post.getTags().split(",")));
        } else {
            dto.setTags(new ArrayList<>());
        }


        dto.setCreatedAt(post.getCreatedAt().toString());
        return dto;
    }
}