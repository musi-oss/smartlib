package com.smartlib;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartLibApplication {
    public static void main(String[] args) {
        SpringApplication.run(SmartLibApplication.class, args);

        System.out.println("========================================");
        System.out.println("🚀 智能图书馆后端启动成功！");
        System.out.println("🔗 后端地址: http://localhost:8080");
        System.out.println("🌐 前端地址: http://localhost:5173");
        System.out.println("📚 数据库: MySQL smart_library");
        System.out.println("👤 测试账号: test / 123456");
        System.out.println("========================================");
    }
}