package com.smartlib.entity;

import lombok.Data;
import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "user")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "username", nullable = false, unique = true, length = 50)
    private String username;

    @Column(name = "password", nullable = false, length = 100)
    private String password;

    @Column(name = "email", length = 100, unique = true)
    private String email;

    @Column(name = "student_id", length = 20)
    private String studentId;

    @Column(name = "phone", length = 20)
    private String phone;

    @Column(name = "avatar", length = 500)
    private String avatar;

    @Column(name = "score")
    private Integer score = 0;

    @Column(name = "borrow_count")
    private Integer borrowCount = 0;

    @Column(name = "current_borrow")
    private Integer currentBorrow = 0;

    @Column(name = "consecutive_days")
    private Integer consecutiveDays = 0;

    @Column(name = "role", length = 20)
    private String role = "USER";

    @Column(name = "status")
    private Integer status = 1;

    @Column(name = "created_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    @Column(name = "updated_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = new Date();
        updatedAt = new Date();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = new Date();
    }
}