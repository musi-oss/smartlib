package com.smartlib.entity;

import lombok.Data;
import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "community_post")
public class CommunityPost {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "user_id")
    private Integer userId;

    @Column(name = "title")
    private String title;

    @Lob
    @Column(name = "content")
    private String content;

    @Column(name = "category")
    private String category;

    @Column(name = "author_name")
    private String authorName;

    @Column(name = "author_avatar")
    private String authorAvatar;

    @Column(name = "views")
    private Integer views = 0;

    @Column(name = "comments")
    private Integer comments = 0;

    @Column(name = "likes")
    private Integer likes = 0;

    @Column(name = "collects")
    private Integer collects = 0;

    @Column(name = "liked")
    private Integer liked = 0;

    @Column(name = "collected")
    private Integer collected = 0;

    @Column(name = "images")
    private String images;

    @Column(name = "tags")
    private String tags;

    @Column(name = "created_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    @Column(name = "updated_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = new Date();
        updatedAt = new Date();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = new Date();
    }
}