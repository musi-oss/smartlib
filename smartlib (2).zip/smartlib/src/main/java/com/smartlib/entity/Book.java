package com.smartlib.entity;

import lombok.Data;
import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "book")
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "title", nullable = false, length = 200)
    private String title;

    @Column(name = "author", nullable = false, length = 100)
    private String author;

    @Column(name = "isbn", length = 20)
    private String isbn;

    @Column(name = "publisher", length = 100)
    private String publisher;

    @Column(name = "category", nullable = false, length = 50)
    private String category;

    @Lob
    @Column(name = "description")
    private String description;

    @Column(name = "cover", length = 500)
    private String cover;

    @Column(name = "rating")
    private Double rating = 0.0;

    @Column(name = "rating_count")
    private Integer ratingCount = 0;

    @Column(name = "borrow_count")
    private Integer borrowCount = 0;

    @Column(name = "stock")
    private Integer stock = 1;

    @Column(name = "available")
    private Integer available = 1;

    @Column(name = "is_new")
    private Integer isNew = 0;

    @Column(name = "is_hot")
    private Integer isHot = 0;

    @Column(name = "tags", length = 500)
    private String tags;

    @Column(name = "created_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    @Column(name = "updated_at")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = new Date();
        updatedAt = new Date();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = new Date();
    }
}