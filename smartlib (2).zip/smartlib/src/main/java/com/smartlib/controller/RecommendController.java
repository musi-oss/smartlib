package com.smartlib.controller;

import com.smartlib.dto.ResponseDTO;
import com.smartlib.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/recommend")
@CrossOrigin(origins = "*")
public class RecommendController {

    @Autowired
    private BookService bookService;

    @GetMapping("/books")
    public ResponseDTO<?> getRecommendedBooks(
            @RequestParam(required = false, defaultValue = "collaborative") String algorithm) {
        try {
            return ResponseDTO.success(bookService.getRecommendedBooks(algorithm));
        } catch (Exception e) {
            return ResponseDTO.error(400, e.getMessage());
        }
    }

    @PostMapping("/books/{id}/like")
    public ResponseDTO<?> likeRecommendation(@PathVariable Integer id) {
        try {
            return ResponseDTO.success("已标记为喜欢");
        } catch (Exception e) {
            return ResponseDTO.error(400, e.getMessage());
        }
    }

    @PostMapping("/books/{id}/dislike")
    public ResponseDTO<?> dislikeRecommendation(@PathVariable Integer id) {
        try {
            return ResponseDTO.success("已标记为不感兴趣");
        } catch (Exception e) {
            return ResponseDTO.error(400, e.getMessage());
        }
    }
}