package com.smartlib.controller;

import com.smartlib.dto.ResponseDTO;
import com.smartlib.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/books")
@CrossOrigin(origins = "*")
public class BookController {

    @Autowired
    private BookService bookService;

    @GetMapping
    public ResponseDTO<?> getBooks(
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String category) {
        try {
            return ResponseDTO.success(bookService.getBooks(page, size, keyword, category));
        } catch (Exception e) {
            return ResponseDTO.error(400, e.getMessage());
        }
    }

    @GetMapping("/{id}")
    public ResponseDTO<?> getBookById(@PathVariable Integer id) {
        try {
            return ResponseDTO.success(bookService.getBookById(id));
        } catch (Exception e) {
            return ResponseDTO.error(400, e.getMessage());
        }
    }

    @GetMapping("/hot")
    public ResponseDTO<?> getHotBooks() {
        try {
            return ResponseDTO.success(bookService.getHotBooks());
        } catch (Exception e) {
            return ResponseDTO.error(400, e.getMessage());
        }
    }

    @GetMapping("/new")
    public ResponseDTO<?> getNewBooks() {
        try {
            return ResponseDTO.success(bookService.getNewBooks());
        } catch (Exception e) {
            return ResponseDTO.error(400, e.getMessage());
        }
    }

    @PostMapping("/{id}/like")
    public ResponseDTO<?> likeBook(@PathVariable Integer id) {
        try {
            return ResponseDTO.success("点赞成功");
        } catch (Exception e) {
            return ResponseDTO.error(400, e.getMessage());
        }
    }
}