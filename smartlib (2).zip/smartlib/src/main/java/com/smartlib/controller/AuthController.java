package com.smartlib.controller;

import com.smartlib.dto.LoginRequestDTO;
import com.smartlib.dto.ResponseDTO;
import com.smartlib.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/login")
    public ResponseDTO<?> login(@RequestBody LoginRequestDTO loginRequest) {
        try {
            return ResponseDTO.success(authService.login(
                    loginRequest.getUsername(),
                    loginRequest.getPassword()
            ));
        } catch (Exception e) {
            return ResponseDTO.error(e.getMessage());
        }
    }

    @PostMapping("/register")
    public ResponseDTO<?> register(@RequestBody Map<String, String> request) {
        try {
            String username = request.get("username");
            String password = request.get("password");
            String email = request.get("email");

            if (username == null || password == null || email == null) {
                return ResponseDTO.error("参数不能为空");
            }

            Map<String, Object> result = authService.register(username, password, email);
            return ResponseDTO.success(result);
        } catch (Exception e) {
            return ResponseDTO.error(e.getMessage());
        }
    }

    @GetMapping("/userinfo")
    public ResponseDTO getUserInfo(@RequestParam Integer userId) {
        try {
            return ResponseDTO.success(authService.getUserInfo(userId));
        } catch (Exception e) {
            return ResponseDTO.error(e.getMessage());
        }
    }
}