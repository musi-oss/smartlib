package com.smartlib.controller;

import com.smartlib.dto.ResponseDTO;
import com.smartlib.service.CommunityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/community")
@CrossOrigin(origins = "*")
public class CommunityController {

    @Autowired
    private CommunityService communityService;

    @GetMapping("/posts")
    public ResponseDTO<?> getPosts(
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String sort,
            @RequestParam(required = false) String keyword) {
        try {
            return ResponseDTO.success(communityService.getPosts(category, sort, keyword));
        } catch (Exception e) {
            return ResponseDTO.error(400, e.getMessage());
        }
    }

    @PostMapping("/posts")
    public ResponseDTO<?> createPost(@RequestBody Map<String, Object> request) {
        try {
            Integer userId = (Integer) request.get("userId");
            String title = (String) request.get("title");
            String content = (String) request.get("content");
            String category = (String) request.get("category");

            if (userId == null || title == null || content == null) {
                return ResponseDTO.error(400, "参数不能为空");
            }

            Map<String, Object> result = communityService.createPost(userId, title, content, category);
            return ResponseDTO.success(result);
        } catch (Exception e) {
            return ResponseDTO.error(400, e.getMessage());
        }
    }

    @PostMapping("/posts/{id}/like")
    public ResponseDTO<?> likePost(@PathVariable Integer id) {
        try {
            return ResponseDTO.success("点赞成功");
        } catch (Exception e) {
            return ResponseDTO.error(400, e.getMessage());
        }
    }
}