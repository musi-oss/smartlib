package com.smartlib.controller;

import com.smartlib.dto.ResponseDTO;
import com.smartlib.dto.UserDTO;
import com.smartlib.service.AuthService;
import com.smartlib.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "*")
public class UserController {

    @Autowired
    private AuthService authService;

    @Autowired
    private UserService userService;

    @GetMapping("/{id}")
    public ResponseDTO<?> getUserById(@PathVariable Integer id) {
        try {
            return ResponseDTO.success(authService.getUserInfo(id));
        } catch (Exception e) {
            return ResponseDTO.error(400, e.getMessage());
        }
    }

    @PutMapping("/{id}")
    public ResponseDTO<?> updateUser(@PathVariable Integer id, @RequestBody UserDTO userDTO) {
        try {
            // 这里简单返回成功，实际应该更新数据库
            return ResponseDTO.success("更新成功");
        } catch (Exception e) {
            return ResponseDTO.error(400, e.getMessage());
        }
    }

    @GetMapping("/{id}/stats")
    public ResponseDTO<?> getUserStats(@PathVariable Integer id) {
        try {
            return ResponseDTO.success(userService.getUserStats(id));
        } catch (Exception e) {
            return ResponseDTO.error(400, e.getMessage());
        }
    }
}