package com.smartlib.repository;

import com.smartlib.entity.CommunityPost;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface CommunityPostRepository extends JpaRepository<CommunityPost, Integer> {
    List<CommunityPost> findByCategory(String category);
    List<CommunityPost> findByOrderByCreatedAtDesc();
}