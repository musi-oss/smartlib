-- 创建数据库
CREATE DATABASE IF NOT EXISTS `smart_library`
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE `smart_library`;

-- 用户表
CREATE TABLE IF NOT EXISTS `user` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `password` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) UNIQUE,
  `student_id` VARCHAR(20),
  `phone` VARCHAR(20),
  `avatar` VARCHAR(500) DEFAULT 'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png',
  `score` INT DEFAULT 0,
  `borrow_count` INT DEFAULT 0,
  `current_borrow` INT DEFAULT 0,
  `consecutive_days` INT DEFAULT 0,
  `role` VARCHAR(20) DEFAULT 'USER',
  `status` INT DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_username` (`username`),
  INDEX `idx_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 图书表
CREATE TABLE IF NOT EXISTS `book` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(200) NOT NULL,
  `author` VARCHAR(100) NOT NULL,
  `isbn` VARCHAR(20),
  `publisher` VARCHAR(100),
  `category` VARCHAR(50) NOT NULL,
  `description` TEXT,
  `cover` VARCHAR(500),
  `rating` DECIMAL(3,1) DEFAULT 0.0,
  `rating_count` INT DEFAULT 0,
  `borrow_count` INT DEFAULT 0,
  `stock` INT DEFAULT 1,
  `total_stock` INT DEFAULT 1,
  `available` INT DEFAULT 1,
  `is_new` INT DEFAULT 0,
  `is_hot` INT DEFAULT 0,
  `tags` VARCHAR(500),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_title` (`title`(50)),
  INDEX `idx_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 借阅记录表
CREATE TABLE IF NOT EXISTS `borrow_record` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `book_id` INT NOT NULL,
  `book_title` VARCHAR(200) NOT NULL,
  `book_author` VARCHAR(100),
  `book_isbn` VARCHAR(20),
  `borrow_date` DATE NOT NULL,
  `due_date` DATE NOT NULL,
  `return_date` DATE,
  `status` VARCHAR(20) DEFAULT 'BORROWED',
  `is_overdue` INT DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `user`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`book_id`) REFERENCES `book`(`id`) ON DELETE CASCADE,
  INDEX `idx_user_id` (`user_id`),
  INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 评论表
CREATE TABLE IF NOT EXISTS `comment` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `book_id` INT NOT NULL,
  `user_name` VARCHAR(50) NOT NULL,
  `avatar` VARCHAR(500),
  `content` TEXT NOT NULL,
  `likes` INT DEFAULT 0,
  `has_liked` INT DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `user`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`book_id`) REFERENCES `book`(`id`) ON DELETE CASCADE,
  INDEX `idx_book_id` (`book_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 社区帖子表
CREATE TABLE IF NOT EXISTS `community_post` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `title` VARCHAR(200) NOT NULL,
  `content` TEXT NOT NULL,
  `category` VARCHAR(50) DEFAULT 'general',
  `author_name` VARCHAR(50),
  `author_avatar` VARCHAR(500),
  `views` INT DEFAULT 0,
  `comments` INT DEFAULT 0,
  `likes` INT DEFAULT 0,
  `collects` INT DEFAULT 0,
  `liked` INT DEFAULT 0,
  `collected` INT DEFAULT 0,
  `images` TEXT,
  `tags` VARCHAR(500),
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `user`(`id`) ON DELETE CASCADE,
  INDEX `idx_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 推荐记录表
CREATE TABLE IF NOT EXISTS `recommendation` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `book_id` INT NOT NULL,
  `algorithm` VARCHAR(50) DEFAULT 'collaborative',
  `reason` VARCHAR(200),
  `score` DECIMAL(5,2) DEFAULT 0.00,
  `is_read` INT DEFAULT 0,
  `is_liked` INT DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `user`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`book_id`) REFERENCES `book`(`id`) ON DELETE CASCADE,
  INDEX `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;