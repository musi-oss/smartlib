USE `smart_library`;

-- 插入测试用户（密码都是：123456）
INSERT INTO `user` (`username`, `password`, `email`, `student_id`, `phone`, `avatar`, `score`, `borrow_count`, `current_borrow`, `consecutive_days`, `role`) VALUES
('test', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iK6pFjyV9i4W5JgYz7J5e6wUQ8Ym', 'test@example.com', '20240001', '13800138000', 'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png', 150, 12, 5, 7, 'USER'),
('admin', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iK6pFjyV9i4W5JgYz7J5e6wUQ8Ym', 'admin@example.com', '20240000', '13900139000', 'https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png', 500, 50, 3, 30, 'ADMIN');

-- 插入测试图书
INSERT INTO `book` (`title`, `author`, `category`, `description`, `cover`, `rating`, `borrow_count`, `stock`, `available`, `is_new`, `is_hot`, `tags`) VALUES
('Vue.js 3设计与实现', '霍春阳', '前端开发', 'Vue.js 3深入解析', 'https://img1.doubanio.com/view/subject/s/public/s34200289.jpg', 9.2, 156, 3, 1, 1, 1, 'Vue,前端'),
('Spring Boot实战', '王松', '后端开发', 'Spring Boot企业级开发', 'https://img2.doubanio.com/view/subject/s/public/s29483747.jpg', 8.7, 89, 2, 1, 0, 1, 'Spring,Java'),
('Python数据分析', '李明', '数据分析', 'Python数据分析实战', 'https://img3.doubanio.com/view/subject/s/public/s29631790.jpg', 9.0, 120, 5, 1, 1, 0, 'Python,数据'),
('深度学习入门', '斋藤康毅', '人工智能', '深度学习经典入门', 'https://img1.doubanio.com/view/subject/s/public/s33514627.jpg', 9.5, 200, 4, 1, 0, 1, 'AI,深度学习');

-- 插入借阅记录
INSERT INTO `borrow_record` (`user_id`, `book_id`, `book_title`, `book_author`, `borrow_date`, `due_date`, `status`) VALUES
(1, 1, 'Vue.js 3设计与实现', '霍春阳', '2025-12-10', '2025-12-24', 'BORROWED'),
(1, 2, 'Spring Boot实战', '王松', '2025-12-01', '2025-12-15', 'RETURNED');

-- 插入评论
INSERT INTO `comment` (`user_id`, `book_id`, `user_name`, `content`, `likes`) VALUES
(1, 1, 'test', '这本书非常不错！', 5),
(2, 1, 'admin', 'Vue 3必读经典', 12);

-- 插入社区帖子
INSERT INTO `community_post` (`user_id`, `title`, `content`, `category`, `author_name`, `views`, `comments`, `likes`, `tags`) VALUES
(1, 'Vue 3.4 新特性深度解析', '分享Vue 3.4新特性...', 'technology', '前端探索者', 1250, 42, 89, 'Vue,前端'),
(2, 'Spring Boot性能优化', 'Spring Boot优化经验...', 'technology', '后端工程师', 890, 23, 45, 'Spring,Java');