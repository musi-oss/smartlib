// 创建 FrontendDataRepository.java
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FrontendDataRepository extends MongoRepository<FrontendData, String> {
    // 空接口即可，Spring会自动实现基本CRUD
}