import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api") // 统一前缀
@CrossOrigin(origins = "http://localhost:5173") // 允许前端访问
public class FrontendAdapterController {

    @Autowired
    private FrontendDataRepository mongoRepo;

    // ============ 适配前端原有的 MongoDB API ============

    // GET /api/data/:id  -> 对应前端获取数据
    @GetMapping("/data/{id}")
    public ResponseEntity<?> getData(@PathVariable String id) {
        Optional<FrontendData> result = mongoRepo.findById(id);
        return result.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // POST /api/data  -> 对应前端保存数据
    @PostMapping("/data")
    public FrontendData saveData(@RequestBody Map<String, Object> requestData) {
        // 从请求中获取id和data
        String id = (String) requestData.get("id");
        Object data = requestData.get("data");

        FrontendData entity = new FrontendData(id, data);
        return mongoRepo.save(entity);
    }

    // PUT /api/data/:id  -> 对应前端更新数据
    @PutMapping("/data/{id}")
    public FrontendData updateData(@PathVariable String id,
                                   @RequestBody Map<String, Object> newData) {
        FrontendData entity = mongoRepo.findById(id)
                .orElse(new FrontendData(id, new HashMap<>()));
        entity.setData(newData.get("data"));
        return mongoRepo.save(entity);
    }

    // DELETE /api/data/:id  -> 对应前端删除数据
    @DeleteMapping("/data/{id}")
    public ResponseEntity<?> deleteData(@PathVariable String id) {
        mongoRepo.deleteById(id);
        return ResponseEntity.ok().build();
    }

    // ============ 同时提供MySQL数据的API（可选） ============

    // 如果前端需要访问MySQL数据，可以这样包装
    @GetMapping("/mysql/users/{id}")
    public ResponseEntity<?> getMysqlUser(@PathVariable Long id) {
        // 这里调用你原有的MySQL服务
        // Object user = yourMysqlService.getUserById(id);
        // return ResponseEntity.ok(user);

        // 临时返回示例数据
        Map<String, Object> user = new HashMap<>();
        user.put("id", id);
        user.put("name", "示例用户");
        user.put("source", "MySQL数据库");
        return ResponseEntity.ok(user);
    }
}