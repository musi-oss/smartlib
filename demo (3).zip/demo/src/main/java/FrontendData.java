// 创建 FrontendData.java
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "frontend_data")
public class FrontendData {
    @Id
    private String id;
    private Object data; // 用Object接收任意JSON数据

    // 构造方法
    public FrontendData() {}

    public FrontendData(String id, Object data) {
        this.id = id;
        this.data = data;
    }

    // getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public Object getData() { return data; }
    public void setData(Object data) { this.data = data; }
}