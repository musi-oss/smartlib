// src/main/java/com/smartlib/mapper/BlockchainRecordMapper.java
package com.smartlib.mapper;

import com.smartlib.entity.BlockchainRecord;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface BlockchainRecordMapper {

    @Insert("INSERT INTO blockchain_record(transaction_id, block_hash, previous_hash, " +
            "transaction_type, user_id, book_id, data, timestamp, status) " +
            "VALUES(#{transactionId}, #{blockHash}, #{previousHash}, #{transactionType}, " +
            "#{userId}, #{bookId}, #{data}, #{timestamp}, #{status})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(BlockchainRecord record);

    @Select("SELECT * FROM blockchain_record")
    List<BlockchainRecord> selectAll();

    @Select("SELECT * FROM blockchain_record WHERE id = #{id}")
    BlockchainRecord selectById(Integer id);

    @Select("SELECT * FROM blockchain_record WHERE transaction_id = #{transactionId}")
    BlockchainRecord selectByTransactionId(String transactionId);

    @Select("SELECT * FROM blockchain_record ORDER BY id DESC LIMIT 1")
    BlockchainRecord selectLast();

    @Select("SELECT * FROM blockchain_record WHERE user_id = #{userId} ORDER BY timestamp DESC")
    List<BlockchainRecord> selectByUserId(Integer userId);

    @Select("SELECT * FROM blockchain_record WHERE book_id = #{bookId} ORDER BY timestamp DESC")
    List<BlockchainRecord> selectByBookId(Integer bookId);

    @Select("SELECT COUNT(*) FROM blockchain_record")
    int count();

    @Update("UPDATE blockchain_record SET status = #{status} WHERE transaction_id = #{transactionId}")
    int updateStatus(@Param("transactionId") String transactionId, @Param("status") String status);

    @Delete("DELETE FROM blockchain_record WHERE id = #{id}")
    int delete(Integer id);
}