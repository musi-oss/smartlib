// src/main/java/com/smartlib/mapper/UserMapper.java
package com.smartlib.mapper;

import com.smartlib.entity.User;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface UserMapper {

    @Select("SELECT * FROM user")
    List<User> selectAll();

    @Select("SELECT * FROM user WHERE id = #{id}")
    User selectById(Integer id);

    @Select("SELECT * FROM user WHERE username = #{username}")
    User selectByUsername(String username);

    @Insert("INSERT INTO user(username, password, email, user_type) " +
            "VALUES(#{username}, #{password}, #{email}, #{userType})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(User user);

    @Update("UPDATE user SET username=#{username}, email=#{email}, " +
            "points=#{points}, borrow_count=#{borrowCount} WHERE id=#{id}")
    int update(User user);

    @Delete("DELETE FROM user WHERE id = #{id}")
    int delete(Integer id);

    @Select("SELECT COUNT(*) FROM user")
    int count();
}