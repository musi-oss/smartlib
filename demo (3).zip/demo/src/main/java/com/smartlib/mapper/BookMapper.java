// src/main/java/com/smartlib/mapper/BookMapper.java
package com.smartlib.mapper;

import com.smartlib.entity.Book;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface BookMapper {

    @Select("SELECT * FROM book")
    List<Book> selectAll();

    @Select("SELECT * FROM book WHERE id = #{id}")
    Book selectById(Integer id);

    @Select("SELECT * FROM book WHERE category = #{category}")
    List<Book> selectByCategory(String category);

    @Select("SELECT * FROM book WHERE title LIKE CONCAT('%', #{keyword}, '%') " +
            "OR author LIKE CONCAT('%', #{keyword}, '%')")
    List<Book> search(String keyword);

    @Insert("INSERT INTO book(title, author, isbn, category, stock, description, tags) " +
            "VALUES(#{title}, #{author}, #{isbn}, #{category}, #{stock}, #{description}, #{tags})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(Book book);

    @Update("UPDATE book SET title=#{title}, author=#{author}, category=#{category}, " +
            "stock=#{stock}, description=#{description}, tags=#{tags} WHERE id=#{id}")
    int update(Book book);

    @Update("UPDATE book SET stock = stock - 1 WHERE id = #{id} AND stock > 0")
    int decreaseStock(Integer id);

    @Update("UPDATE book SET stock = stock + 1 WHERE id = #{id}")
    int increaseStock(Integer id);

    @Delete("DELETE FROM book WHERE id = #{id}")
    int delete(Integer id);
}