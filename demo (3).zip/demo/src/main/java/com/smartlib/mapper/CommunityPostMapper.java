// src/main/java/com/smartlib/mapper/CommunityPostMapper.java
package com.smartlib.mapper;

import com.smartlib.entity.CommunityPost;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface CommunityPostMapper {

    @Insert("INSERT INTO community_post(user_id, title, content, post_type, view_count, " +
            "like_count, comment_count, tags, status) " +
            "VALUES(#{userId}, #{title}, #{content}, #{postType}, #{viewCount}, " +
            "#{likeCount}, #{commentCount}, #{tags}, #{status})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(CommunityPost post);

    @Update("UPDATE community_post SET title=#{title}, content=#{content}, " +
            "post_type=#{postType}, tags=#{tags}, update_time=NOW() " +
            "WHERE id=#{id} AND user_id=#{userId}")
    int update(CommunityPost post);

    @Update("UPDATE community_post SET status='DELETED' WHERE id=#{id}")
    int delete(Integer id);

    @Update("UPDATE community_post SET view_count = view_count + 1 WHERE id=#{id}")
    int increaseViewCount(Integer id);

    @Update("UPDATE community_post SET like_count = like_count + #{delta} WHERE id=#{id}")
    int updateLikeCount(@Param("id") Integer id, @Param("delta") Integer delta);

    @Update("UPDATE community_post SET comment_count = comment_count + #{delta} WHERE id=#{id}")
    int updateCommentCount(@Param("id") Integer id, @Param("delta") Integer delta);

    @Select("SELECT * FROM community_post WHERE id=#{id} AND status='PUBLISHED'")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "author", column = "user_id",
                    one = @One(select = "com.smartlib.mapper.UserMapper.selectById"))
    })
    CommunityPost selectById(Integer id);

    @Select("SELECT * FROM community_post WHERE status='PUBLISHED' ORDER BY create_time DESC")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "author", column = "user_id",
                    one = @One(select = "com.smartlib.mapper.UserMapper.selectById"))
    })
    List<CommunityPost> selectAll();

    @Select("SELECT * FROM community_post WHERE user_id=#{userId} AND status='PUBLISHED' " +
            "ORDER BY create_time DESC")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "author", column = "user_id",
                    one = @One(select = "com.smartlib.mapper.UserMapper.selectById"))
    })
    List<CommunityPost> selectByUserId(Integer userId);

    @Select("SELECT * FROM community_post WHERE post_type=#{postType} AND status='PUBLISHED' " +
            "ORDER BY create_time DESC")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "author", column = "user_id",
                    one = @One(select = "com.smartlib.mapper.UserMapper.selectById"))
    })
    List<CommunityPost> selectByType(String postType);

    @Select("SELECT * FROM community_post WHERE tags LIKE CONCAT('%', #{tag}, '%') " +
            "AND status='PUBLISHED' ORDER BY create_time DESC")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "author", column = "user_id",
                    one = @One(select = "com.smartlib.mapper.UserMapper.selectById"))
    })
    List<CommunityPost> selectByTag(String tag);

    @Select("SELECT * FROM community_post WHERE title LIKE CONCAT('%', #{keyword}, '%') " +
            "OR content LIKE CONCAT('%', #{keyword}, '%') AND status='PUBLISHED' " +
            "ORDER BY create_time DESC")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "author", column = "user_id",
                    one = @One(select = "com.smartlib.mapper.UserMapper.selectById"))
    })
    List<CommunityPost> search(String keyword);

    @Select("SELECT * FROM community_post WHERE status='PUBLISHED' " +
            "ORDER BY like_count DESC, view_count DESC LIMIT #{limit}")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "author", column = "user_id",
                    one = @One(select = "com.smartlib.mapper.UserMapper.selectById"))
    })
    List<CommunityPost> selectPopular(@Param("limit") Integer limit);
}