// src/main/java/com/smartlib/mapper/CommunityCommentMapper.java
package com.smartlib.mapper;

import com.smartlib.entity.CommunityComment;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface CommunityCommentMapper {

    @Insert("INSERT INTO community_comment(post_id, user_id, parent_id, content) " +
            "VALUES(#{postId}, #{userId}, #{parentId}, #{content})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(CommunityComment comment);

    @Update("UPDATE community_comment SET content=#{content} WHERE id=#{id} AND user_id=#{userId}")
    int update(CommunityComment comment);

    @Delete("DELETE FROM community_comment WHERE id=#{id}")
    int delete(Integer id);

    @Update("UPDATE community_comment SET like_count = like_count + #{delta} WHERE id=#{id}")
    int updateLikeCount(@Param("id") Integer id, @Param("delta") Integer delta);

    @Select("SELECT * FROM community_comment WHERE id=#{id}")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "author", column = "user_id",
                    one = @One(select = "com.smartlib.mapper.UserMapper.selectById")),
            @Result(property = "post", column = "post_id",
                    one = @One(select = "com.smartlib.mapper.CommunityPostMapper.selectById"))
    })
    CommunityComment selectById(Integer id);

    @Select("SELECT * FROM community_comment WHERE post_id=#{postId} ORDER BY create_time ASC")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "author", column = "user_id",
                    one = @One(select = "com.smartlib.mapper.UserMapper.selectById"))
    })
    List<CommunityComment> selectByPostId(Integer postId);

    @Select("SELECT * FROM community_comment WHERE user_id=#{userId} ORDER BY create_time DESC")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "author", column = "user_id",
                    one = @One(select = "com.smartlib.mapper.UserMapper.selectById")),
            @Result(property = "post", column = "post_id",
                    one = @One(select = "com.smartlib.mapper.CommunityPostMapper.selectById"))
    })
    List<CommunityComment> selectByUserId(Integer userId);

    @Select("SELECT * FROM community_comment WHERE parent_id=#{parentId} ORDER BY create_time ASC")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "author", column = "user_id",
                    one = @One(select = "com.smartlib.mapper.UserMapper.selectById"))
    })
    List<CommunityComment> selectReplies(Integer parentId);

    @Select("SELECT COUNT(*) FROM community_comment WHERE post_id=#{postId}")
    int countByPostId(Integer postId);
}