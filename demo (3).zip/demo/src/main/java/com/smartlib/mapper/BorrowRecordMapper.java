// src/main/java/com/smartlib/mapper/BorrowRecordMapper.java
package com.smartlib.mapper;

import com.smartlib.entity.BorrowRecord;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface BorrowRecordMapper {

    @Insert("INSERT INTO borrow_record(user_id, book_id, borrow_time, expected_return_time, " +
            "actual_return_time, status, overdue_days, penalty, remarks) " +
            "VALUES(#{userId}, #{bookId}, #{borrowTime}, #{expectedReturnTime}, " +
            "#{actualReturnTime}, #{status}, #{overdueDays}, #{penalty}, #{remarks})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(BorrowRecord record);

    @Update("UPDATE borrow_record SET " +
            "actual_return_time=#{actualReturnTime}, status=#{status}, " +
            "overdue_days=#{overdueDays}, penalty=#{penalty}, remarks=#{remarks} " +
            "WHERE id=#{id}")
    int update(BorrowRecord record);

    @Select("SELECT * FROM borrow_record WHERE id=#{id}")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "book", column = "book_id",
                    one = @One(select = "com.smartlib.mapper.BookMapper.selectById")),
            @Result(property = "user", column = "user_id",
                    one = @One(select = "com.smartlib.mapper.UserMapper.selectById"))
    })
    BorrowRecord selectById(Integer id);

    @Select("SELECT * FROM borrow_record WHERE user_id=#{userId} ORDER BY borrow_time DESC")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "book", column = "book_id",
                    one = @One(select = "com.smartlib.mapper.BookMapper.selectById"))
    })
    List<BorrowRecord> selectByUserId(Integer userId);

    @Select("SELECT * FROM borrow_record WHERE book_id=#{bookId} ORDER BY borrow_time DESC")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "user", column = "user_id",
                    one = @One(select = "com.smartlib.mapper.UserMapper.selectById"))
    })
    List<BorrowRecord> selectByBookId(Integer bookId);

    @Select("SELECT * FROM borrow_record WHERE status=#{status} ORDER BY borrow_time DESC")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "book", column = "book_id",
                    one = @One(select = "com.smartlib.mapper.BookMapper.selectById")),
            @Result(property = "user", column = "user_id",
                    one = @One(select = "com.smartlib.mapper.UserMapper.selectById"))
    })
    List<BorrowRecord> selectByStatus(String status);

    @Select("SELECT * FROM borrow_record ORDER BY borrow_time DESC")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "book", column = "book_id",
                    one = @One(select = "com.smartlib.mapper.BookMapper.selectById")),
            @Result(property = "user", column = "user_id",
                    one = @One(select = "com.smartlib.mapper.UserMapper.selectById"))
    })
    List<BorrowRecord> selectAll();

    @Select("SELECT COUNT(*) FROM borrow_record WHERE user_id=#{userId} AND status='BORROWED'")
    int countBorrowingByUserId(Integer userId);

    @Select("SELECT * FROM borrow_record WHERE status='BORROWED' AND expected_return_time < NOW()")
    List<BorrowRecord> selectOverdueRecords();

    @Delete("DELETE FROM borrow_record WHERE id=#{id}")
    int delete(Integer id);
}