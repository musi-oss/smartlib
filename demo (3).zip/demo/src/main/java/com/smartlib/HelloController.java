// src/main/java/com/smartlib/controller/HelloController.java
package com.smartlib;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

    @GetMapping("/hello")
    public String hello() {
        return "Hello SmartLib! 应用启动成功！时间：" + new java.util.Date();
    }

    @GetMapping("/health")
    public String health() {
        return "{\"status\":\"UP\",\"timestamp\":\"" + System.currentTimeMillis() + "\"}";
    }
}