// src/main/java/com/smartlib/entity/BlockchainRecord.java
package com.smartlib.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BlockchainRecord {
    private Integer id;
    private String transactionId;      // 交易ID，唯一标识
    private String blockHash;          // 当前区块哈希
    private String previousHash;       // 前一个区块哈希
    private String transactionType;    // 交易类型：BORROW/RETURN/TRANSFER/BUY
    private Integer userId;            // 用户ID
    private Integer bookId;            // 图书ID
    private String data;               // 交易详情JSON
    private Long timestamp;            // 时间戳
    private Date createTime;           // 创建时间
    private String status;             // 状态：PENDING/CONFIRMED

    // 简化构造函数
    public BlockchainRecord(String transactionType, Integer userId, Integer bookId, String data) {
        this.transactionType = transactionType;
        this.userId = userId;
        this.bookId = bookId;
        this.data = data;
        this.timestamp = System.currentTimeMillis();
        this.createTime = new Date();
        this.status = "CONFIRMED";
    }
}