// src/main/java/com/smartlib/entity/User.java
package com.smartlib.entity;

import lombok.Data;
import java.util.Date;

@Data
public class User {
    private Integer id;
    private String username;
    private String password;
    private String email;
    private String avatarUrl;
    private Integer points;
    private Integer borrowCount;
    private String userType;  // STUDENT, ADMIN, TEACHER
    private Date createdAt;
    private Date updatedAt;
}