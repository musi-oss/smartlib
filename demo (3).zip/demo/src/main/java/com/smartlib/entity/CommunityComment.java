// src/main/java/com/smartlib/entity/CommunityComment.java
package com.smartlib.entity;

import lombok.Data;
import java.util.Date;

@Data
public class CommunityComment {
    private Integer id;
    private Integer postId;
    private Integer userId;
    private Integer parentId; // 0表示主评论，否则是回复
    private String content;
    private Integer likeCount;
    private Date createTime;

    // 关联信息
    private User author;
    private CommunityPost post;

    // 简化构造函数
    public CommunityComment() {
        this.likeCount = 0;
        this.createTime = new Date();
    }
}