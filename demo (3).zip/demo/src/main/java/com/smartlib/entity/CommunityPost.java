// src/main/java/com/smartlib/entity/CommunityPost.java
package com.smartlib.entity;

import lombok.Data;
import java.util.Date;
import java.util.List;

@Data
public class CommunityPost {
    private Integer id;
    private Integer userId;
    private String title;
    private String content;
    private String postType; // NOTE(笔记), QUESTION(提问), SHARING(分享)
    private Integer viewCount;
    private Integer likeCount;
    private Integer commentCount;
    private String tags;
    private Date createTime;
    private Date updateTime;
    private String status; // PUBLISHED, DELETED

    // 关联信息
    private User author;
    private List<CommunityComment> comments;

    // 简化构造函数
    public CommunityPost() {
        this.viewCount = 0;
        this.likeCount = 0;
        this.commentCount = 0;
        this.createTime = new Date();
        this.updateTime = new Date();
        this.status = "PUBLISHED";
    }
}