// src/main/java/com/smartlib/entity/Book.java
package com.smartlib.entity;

import lombok.Data;
import java.util.Date;

@Data
public class Book {
    private Integer id;
    private String title;
    private String author;
    private String isbn;
    private String coverUrl;
    private String category;
    private Integer stock;
    private String description;
    private String tags;
    private Date createdAt;
}