// src/main/java/com/smartlib/entity/BorrowRecord.java
package com.smartlib.entity;

import lombok.Data;
import java.util.Date;

@Data
public class BorrowRecord {
    private Integer id;
    private Integer userId;
    private Integer bookId;
    private Date borrowTime;
    private Date expectedReturnTime;
    private Date actualReturnTime;
    private String status; // BORROWED, RETURNED, OVERDUE
    private Integer overdueDays;
    private Double penalty;
    private String remarks;
    private Date createTime;

    // 关联的图书和用户信息（用于查询）
    private Book book;
    private User user;
}