// src/main/java/com/smartlib/SmartLibApplication.java
package com.smartlib;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
@MapperScan("com.smartlib.mapper")  // 扫描MyBatis的Mapper接口
public class SmartLibApplication {
    public static void main(String[] args) {
        try {
            SpringApplication.run(SmartLibApplication.class, args);
            System.out.println("==========================================");
            System.out.println("✅ 智能图书管理系统启动成功！");
            System.out.println("✅ 访问地址：http://localhost:8080");
            System.out.println("✅ 数据库：smart_library");
            System.out.println("✅ Spring Boot版本：2.7.18");
            System.out.println("==========================================");
        } catch (Exception e) {
            System.err.println("❌ 启动失败：" + e.getMessage());
            e.printStackTrace();
        }
    }
}