// src/main/java/com/smartlib/service/BlockchainService.java
package com.smartlib.service;

import com.smartlib.entity.BlockchainRecord;
import java.util.List;

public interface BlockchainService {

    /**
     * 创建借阅交易
     */
    BlockchainRecord createBorrowTransaction(Integer userId, Integer bookId,
                                             Integer borrowDays, String bookTitle);

    /**
     * 创建归还交易
     */
    BlockchainRecord createReturnTransaction(Integer userId, Integer bookId,
                                             String condition, String bookTitle);

    /**
     * 创建图书转让交易
     */
    BlockchainRecord createTransferTransaction(Integer fromUserId, Integer toUserId,
                                               Integer bookId, Double price, String bookTitle);

    /**
     * 获取完整区块链
     */
    List<BlockchainRecord> getBlockchain();

    /**
     * 验证区块链完整性
     */
    boolean validateChain();

    /**
     * 获取用户交易历史
     */
    List<BlockchainRecord> getUserHistory(Integer userId);

    /**
     * 获取图书交易历史
     */
    List<BlockchainRecord> getBookHistory(Integer bookId);
}