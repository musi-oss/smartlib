// src/main/java/com/smartlib/service/RecommendService.java
package com.smartlib.service;

import com.smartlib.entity.Book;
import java.util.List;
import java.util.Map;

public interface RecommendService {

    // 基于用户的协同过滤推荐
    List<Book> recommendByUserCF(Integer userId, Integer limit);

    // 基于物品的协同过滤推荐
    List<Book> recommendByItemCF(Integer userId, Integer limit);

    // 基于内容的推荐（图书标签）
    List<Book> recommendByContent(Integer userId, Integer limit);

    // 热门推荐
    List<Book> recommendHot(Integer limit);

    // 新书推荐
    List<Book> recommendNew(Integer limit);

    // 混合推荐（综合多种算法）
    List<Book> recommendHybrid(Integer userId, Integer limit);

    // 获取推荐理由
    Map<String, Object> getRecommendationReason(Integer userId, Integer bookId);

    // 更新用户偏好（用户行为记录）
    void recordUserAction(Integer userId, Integer bookId, String actionType);
}