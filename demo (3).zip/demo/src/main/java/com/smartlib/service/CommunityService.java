// src/main/java/com/smartlib/service/CommunityService.java
package com.smartlib.service;

import com.smartlib.entity.CommunityPost;
import com.smartlib.entity.CommunityComment;
import java.util.List;

public interface CommunityService {

    // 帖子相关
    CommunityPost createPost(CommunityPost post);
    CommunityPost updatePost(CommunityPost post);
    boolean deletePost(Integer postId, Integer userId);
    CommunityPost getPostById(Integer id);
    List<CommunityPost> getAllPosts();
    List<CommunityPost> getPostsByUser(Integer userId);
    List<CommunityPost> getPostsByType(String postType);
    List<CommunityPost> searchPosts(String keyword);
    List<CommunityPost> getPopularPosts(Integer limit);
    boolean likePost(Integer postId, Integer userId);
    boolean unlikePost(Integer postId, Integer userId);

    // 评论相关
    CommunityComment createComment(CommunityComment comment);
    CommunityComment updateComment(CommunityComment comment);
    boolean deleteComment(Integer commentId, Integer userId);
    List<CommunityComment> getCommentsByPost(Integer postId);
    List<CommunityComment> getCommentsByUser(Integer userId);
    boolean likeComment(Integer commentId, Integer userId);

    // 统计相关
    Integer getUserPostCount(Integer userId);
    Integer getUserCommentCount(Integer userId);
}