// src/main/java/com/smartlib/service/DatabaseTestService.java
package com.smartlib.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

@Service
public class DatabaseTestService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @PostConstruct
    public void testDatabaseConnection() {
        try {
            // 测试数据库连接
            String result = jdbcTemplate.queryForObject("SELECT '数据库连接成功!' as message", String.class);
            System.out.println("✅ " + result);

            // 检查表是否存在
            Integer tableCount = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'smart_library'",
                    Integer.class
            );
            System.out.println("✅ 数据库中有 " + tableCount + " 张表");

        } catch (Exception e) {
            System.err.println("❌ 数据库连接失败: " + e.getMessage());
        }
    }
}