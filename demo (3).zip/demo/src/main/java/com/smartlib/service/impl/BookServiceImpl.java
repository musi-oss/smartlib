// src/main/java/com/smartlib/service/impl/BookServiceImpl.java
package com.smartlib.service.impl;

import com.smartlib.entity.Book;
import com.smartlib.mapper.BookMapper;
import com.smartlib.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service
public class BookServiceImpl implements BookService {

    @Autowired
    private BookMapper bookMapper;

    @Override
    @Transactional
    public Book addBook(Book book) {
        book.setCreatedAt(new Date());
        bookMapper.insert(book);
        return book;
    }

    @Override
    @Transactional
    public Book updateBook(Book book) {
        Book existingBook = bookMapper.selectById(book.getId());
        if (existingBook == null) {
            throw new RuntimeException("图书不存在");
        }

        // 更新字段
        if (book.getTitle() != null) existingBook.setTitle(book.getTitle());
        if (book.getAuthor() != null) existingBook.setAuthor(book.getAuthor());
        if (book.getIsbn() != null) existingBook.setIsbn(book.getIsbn());
        if (book.getCategory() != null) existingBook.setCategory(book.getCategory());
        if (book.getStock() != null) existingBook.setStock(book.getStock());
        if (book.getDescription() != null) existingBook.setDescription(book.getDescription());
        if (book.getTags() != null) existingBook.setTags(book.getTags());
        if (book.getCoverUrl() != null) existingBook.setCoverUrl(book.getCoverUrl());

        bookMapper.update(existingBook);
        return existingBook;
    }

    @Override
    @Transactional
    public boolean deleteBook(Integer id) {
        return bookMapper.delete(id) > 0;
    }

    @Override
    public Book getBookById(Integer id) {
        return bookMapper.selectById(id);
    }

    @Override
    public List<Book> getAllBooks() {
        return bookMapper.selectAll();
    }

    @Override
    public List<Book> searchBooks(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return getAllBooks();
        }
        return bookMapper.search(keyword.trim());
    }

    @Override
    public List<Book> getBooksByCategory(String category) {
        return bookMapper.selectByCategory(category);
    }

    @Override
    @Transactional
    public boolean decreaseStock(Integer bookId, Integer quantity) {
        Book book = bookMapper.selectById(bookId);
        if (book == null || book.getStock() < quantity) {
            return false;
        }

        // 多次调用减少库存
        for (int i = 0; i < quantity; i++) {
            bookMapper.decreaseStock(bookId);
        }
        return true;
    }

    @Override
    @Transactional
    public boolean increaseStock(Integer bookId, Integer quantity) {
        Book book = bookMapper.selectById(bookId);
        if (book == null) {
            return false;
        }

        // 多次调用增加库存
        for (int i = 0; i < quantity; i++) {
            bookMapper.increaseStock(bookId);
        }
        return true;
    }

    @Override
    public List<Book> getPopularBooks(Integer limit) {
        List<Book> allBooks = getAllBooks();
        // 简单实现：按库存倒序（实际应该按借阅次数）
        allBooks.sort((b1, b2) -> b2.getStock().compareTo(b1.getStock()));
        return limit != null && allBooks.size() > limit ?
                allBooks.subList(0, Math.min(limit, allBooks.size())) : allBooks;
    }

    @Override
    public List<Book> getRecommendedBooks(Integer userId) {
        // 简化推荐：返回热门图书
        return getPopularBooks(10);
    }
}