// src/main/java/com/smartlib/service/impl/BorrowServiceImpl.java
package com.smartlib.service.impl;

import com.smartlib.entity.BorrowRecord;
import com.smartlib.entity.Book;
import com.smartlib.entity.User;
import com.smartlib.mapper.BorrowRecordMapper;
import com.smartlib.mapper.BookMapper;
import com.smartlib.mapper.UserMapper;
import com.smartlib.service.BlockchainService;
import com.smartlib.service.BorrowService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class BorrowServiceImpl implements BorrowService {

    @Autowired
    private BorrowRecordMapper borrowRecordMapper;

    @Autowired
    private BookMapper bookMapper;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private BlockchainService blockchainService;

    @Override
    @Transactional
    public BorrowRecord borrowBook(Integer userId, Integer bookId, Integer borrowDays) {
        // 1. 检查用户和图书是否存在
        User user = userMapper.selectById(userId);
        Book book = bookMapper.selectById(bookId);

        if (user == null) {
            throw new RuntimeException("用户不存在");
        }
        if (book == null) {
            throw new RuntimeException("图书不存在");
        }
        if (book.getStock() <= 0) {
            throw new RuntimeException("图书库存不足");
        }

        // 2. 检查用户是否已达到最大借阅数量
        int borrowingCount = borrowRecordMapper.countBorrowingByUserId(userId);
        if (borrowingCount >= 5) { // 假设最大借阅5本
            throw new RuntimeException("已达到最大借阅数量");
        }

        // 3. 减少图书库存
        boolean stockUpdated = bookMapper.decreaseStock(bookId) > 0;
        if (!stockUpdated) {
            throw new RuntimeException("更新库存失败");
        }

        // 4. 创建借阅记录
        Date now = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(now);
        calendar.add(Calendar.DAY_OF_MONTH, borrowDays);

        BorrowRecord record = new BorrowRecord();
        record.setUserId(userId);
        record.setBookId(bookId);
        record.setBorrowTime(now);
        record.setExpectedReturnTime(calendar.getTime());
        record.setStatus("BORROWED");
        record.setCreateTime(now);

        borrowRecordMapper.insert(record);

        // 5. 更新用户借阅次数
        user.setBorrowCount(user.getBorrowCount() + 1);
        userMapper.update(user);

        // 6. 记录到区块链
        blockchainService.createBorrowTransaction(userId, bookId, borrowDays, book.getTitle());

        return record;
    }

    @Override
    @Transactional
    public BorrowRecord returnBook(Integer borrowRecordId, String condition) {
        BorrowRecord record = borrowRecordMapper.selectById(borrowRecordId);
        if (record == null) {
            throw new RuntimeException("借阅记录不存在");
        }
        if ("RETURNED".equals(record.getStatus())) {
            throw new RuntimeException("图书已归还");
        }

        Date now = new Date();
        record.setActualReturnTime(now);
        record.setStatus("RETURNED");
        record.setRemarks("归还状态：" + condition);

        // 计算逾期
        if (now.after(record.getExpectedReturnTime())) {
            long diff = now.getTime() - record.getExpectedReturnTime().getTime();
            int overdueDays = (int) (diff / (1000 * 60 * 60 * 24));
            record.setOverdueDays(overdueDays);
            // 逾期罚金：每天0.5元
            record.setPenalty(overdueDays * 0.5);
        }

        borrowRecordMapper.update(record);

        // 增加图书库存
        bookMapper.increaseStock(record.getBookId());

        // 记录到区块链
        Book book = bookMapper.selectById(record.getBookId());
        blockchainService.createReturnTransaction(
                record.getUserId(), record.getBookId(), condition, book.getTitle());

        return record;
    }

    @Override
    @Transactional
    public BorrowRecord renewBook(Integer borrowRecordId, Integer extraDays) {
        BorrowRecord record = borrowRecordMapper.selectById(borrowRecordId);
        if (record == null) {
            throw new RuntimeException("借阅记录不存在");
        }

        // 延长归还时间
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(record.getExpectedReturnTime());
        calendar.add(Calendar.DAY_OF_MONTH, extraDays);
        record.setExpectedReturnTime(calendar.getTime());

        borrowRecordMapper.update(record);
        return record;
    }

    @Override
    public BorrowRecord getBorrowRecord(Integer id) {
        return borrowRecordMapper.selectById(id);
    }

    @Override
    public List<BorrowRecord> getUserBorrowHistory(Integer userId) {
        return borrowRecordMapper.selectByUserId(userId);
    }

    @Override
    public List<BorrowRecord> getBookBorrowHistory(Integer bookId) {
        return borrowRecordMapper.selectByBookId(bookId);
    }

    @Override
    public List<BorrowRecord> getBorrowingRecords(Integer userId) {
        List<BorrowRecord> allRecords = borrowRecordMapper.selectByUserId(userId);
        return allRecords.stream()
                .filter(r -> "BORROWED".equals(r.getStatus()))
                .collect(Collectors.toList());
    }

    @Override
    public List<BorrowRecord> getAllBorrowRecords() {
        return borrowRecordMapper.selectAll();
    }

    @Override
    public List<BorrowRecord> checkOverdueRecords() {
        return borrowRecordMapper.selectOverdueRecords();
    }

    @Override
    public Double calculatePenalty(Integer borrowRecordId) {
        BorrowRecord record = borrowRecordMapper.selectById(borrowRecordId);
        if (record == null || record.getPenalty() == null) {
            return 0.0;
        }
        return record.getPenalty();
    }
}