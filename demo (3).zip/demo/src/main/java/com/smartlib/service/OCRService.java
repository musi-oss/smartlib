// src/main/java/com/smartlib/service/OCRService.java
package com.smartlib.service;

import com.smartlib.entity.Book;
import org.springframework.web.multipart.MultipartFile;
import java.util.Map;

public interface OCRService {

    // 调用百度OCR识别图书信息
    Map<String, Object> recognizeBookInfo(MultipartFile imageFile);

    // 从OCR结果中提取图书信息并创建图书
    Book createBookFromOCR(MultipartFile imageFile, Integer userId);

    // 获取OCR识别历史
    Map<String, Object> getOCRHistory(Integer userId);
}