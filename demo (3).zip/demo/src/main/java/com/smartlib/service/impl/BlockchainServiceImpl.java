// src/main/java/com/smartlib/service/impl/BlockchainServiceImpl.java
package com.smartlib.service.impl;

import com.smartlib.entity.BlockchainRecord;
import com.smartlib.mapper.BlockchainRecordMapper;
import com.smartlib.service.BlockchainService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

@Slf4j
@Service
public class BlockchainServiceImpl implements BlockchainService {

    @Autowired
    private BlockchainRecordMapper blockchainRecordMapper;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    @Transactional
    public BlockchainRecord createBorrowTransaction(Integer userId, Integer bookId,
                                                    Integer borrowDays, String bookTitle) {
        try {
            // 准备交易数据
            Map<String, Object> dataMap = new HashMap<>();
            dataMap.put("type", "borrow");
            dataMap.put("userId", userId);
            dataMap.put("bookId", bookId);
            dataMap.put("bookTitle", bookTitle);
            dataMap.put("borrowDays", borrowDays);
            dataMap.put("fee", 0);
            dataMap.put("timestamp", System.currentTimeMillis());
            String data = objectMapper.writeValueAsString(dataMap);

            // 生成交易ID
            String transactionId = "BORROW-" + UUID.randomUUID().toString().substring(0, 8);

            // 获取前一个区块哈希
            BlockchainRecord lastRecord = blockchainRecordMapper.selectLast();
            String previousHash = lastRecord != null ? lastRecord.getBlockHash() : "0";

            // 计算当前区块哈希
            String input = transactionId + userId + bookId + data + System.currentTimeMillis();
            String blockHash = calculateSHA256(input);

            // 创建记录
            BlockchainRecord record = new BlockchainRecord();
            record.setTransactionId(transactionId);
            record.setBlockHash(blockHash);
            record.setPreviousHash(previousHash);
            record.setTransactionType("BORROW");
            record.setUserId(userId);
            record.setBookId(bookId);
            record.setData(data);
            record.setTimestamp(System.currentTimeMillis());
            record.setStatus("CONFIRMED");

            // 保存到数据库
            blockchainRecordMapper.insert(record);

            // 写入日志文件（模拟区块链存储）
            writeToBlockchainFile(record);

            log.info("✅ 创建借阅交易成功: {}", transactionId);
            return record;

        } catch (Exception e) {
            log.error("❌ 创建借阅交易失败", e);
            throw new RuntimeException("创建借阅交易失败: " + e.getMessage());
        }
    }

    @Override
    @Transactional
    public BlockchainRecord createReturnTransaction(Integer userId, Integer bookId,
                                                    String condition, String bookTitle) {
        try {
            Map<String, Object> dataMap = new HashMap<>();
            dataMap.put("type", "return");
            dataMap.put("userId", userId);
            dataMap.put("bookId", bookId);
            dataMap.put("bookTitle", bookTitle);
            dataMap.put("condition", condition);
            dataMap.put("penalty", 0);
            dataMap.put("timestamp", System.currentTimeMillis());
            String data = objectMapper.writeValueAsString(dataMap);

            String transactionId = "RETURN-" + UUID.randomUUID().toString().substring(0, 8);

            BlockchainRecord lastRecord = blockchainRecordMapper.selectLast();
            String previousHash = lastRecord != null ? lastRecord.getBlockHash() : "0";

            String input = transactionId + userId + bookId + data + System.currentTimeMillis();
            String blockHash = calculateSHA256(input);

            BlockchainRecord record = new BlockchainRecord();
            record.setTransactionId(transactionId);
            record.setBlockHash(blockHash);
            record.setPreviousHash(previousHash);
            record.setTransactionType("RETURN");
            record.setUserId(userId);
            record.setBookId(bookId);
            record.setData(data);
            record.setTimestamp(System.currentTimeMillis());
            record.setStatus("CONFIRMED");

            blockchainRecordMapper.insert(record);
            writeToBlockchainFile(record);

            log.info("✅ 创建归还交易成功: {}", transactionId);
            return record;

        } catch (Exception e) {
            log.error("❌ 创建归还交易失败", e);
            throw new RuntimeException("创建归还交易失败: " + e.getMessage());
        }
    }

    @Override
    @Transactional
    public BlockchainRecord createTransferTransaction(Integer fromUserId, Integer toUserId,
                                                      Integer bookId, Double price, String bookTitle) {
        try {
            Map<String, Object> dataMap = new HashMap<>();
            dataMap.put("type", "transfer");
            dataMap.put("fromUserId", fromUserId);
            dataMap.put("toUserId", toUserId);
            dataMap.put("bookId", bookId);
            dataMap.put("bookTitle", bookTitle);
            dataMap.put("price", price);
            dataMap.put("timestamp", System.currentTimeMillis());
            String data = objectMapper.writeValueAsString(dataMap);

            String transactionId = "TRANSFER-" + UUID.randomUUID().toString().substring(0, 8);

            BlockchainRecord lastRecord = blockchainRecordMapper.selectLast();
            String previousHash = lastRecord != null ? lastRecord.getBlockHash() : "0";

            String input = transactionId + fromUserId + toUserId + bookId + data + System.currentTimeMillis();
            String blockHash = calculateSHA256(input);

            BlockchainRecord record = new BlockchainRecord();
            record.setTransactionId(transactionId);
            record.setBlockHash(blockHash);
            record.setPreviousHash(previousHash);
            record.setTransactionType("TRANSFER");
            record.setUserId(fromUserId);
            record.setBookId(bookId);
            record.setData(data);
            record.setTimestamp(System.currentTimeMillis());
            record.setStatus("CONFIRMED");

            blockchainRecordMapper.insert(record);
            writeToBlockchainFile(record);

            log.info("✅ 创建转让交易成功: {}", transactionId);
            return record;

        } catch (Exception e) {
            log.error("❌ 创建转让交易失败", e);
            throw new RuntimeException("创建转让交易失败: " + e.getMessage());
        }
    }

    @Override
    public List<BlockchainRecord> getBlockchain() {
        try {
            return blockchainRecordMapper.selectAll();
        } catch (Exception e) {
            log.error("❌ 获取区块链失败", e);
            throw new RuntimeException("获取区块链失败: " + e.getMessage());
        }
    }

    @Override
    public boolean validateChain() {
        try {
            List<BlockchainRecord> records = blockchainRecordMapper.selectAll();
            if (records.isEmpty() || records.size() == 1) {
                return true; // 空链或只有一个区块视为有效
            }

            // 验证第一个区块（创世区块）
            BlockchainRecord first = records.get(0);
            if (!"0".equals(first.getPreviousHash())) {
                log.warn("❌ 创世区块的previousHash不为0");
                return false;
            }

            // 验证链的连续性
            for (int i = 1; i < records.size(); i++) {
                BlockchainRecord current = records.get(i);
                BlockchainRecord previous = records.get(i - 1);

                // 检查哈希链接
                if (!current.getPreviousHash().equals(previous.getBlockHash())) {
                    log.warn("❌ 区块链断裂: 区块{}的前哈希不等于区块{}的哈希",
                            current.getId(), previous.getId());
                    return false;
                }

                // 验证当前区块哈希是否正确
                String input = current.getTransactionId() + current.getUserId() +
                        current.getBookId() + current.getData() + current.getTimestamp();
                String calculatedHash = calculateSHA256(input);

                if (!calculatedHash.equals(current.getBlockHash())) {
                    log.warn("❌ 区块{}哈希验证失败", current.getId());
                    return false;
                }
            }

            log.info("✅ 区块链验证通过，共{}个区块", records.size());
            return true;

        } catch (Exception e) {
            log.error("❌ 区块链验证异常", e);
            return false;
        }
    }

    @Override
    public List<BlockchainRecord> getUserHistory(Integer userId) {
        try {
            return blockchainRecordMapper.selectByUserId(userId);
        } catch (Exception e) {
            log.error("❌ 获取用户历史失败", e);
            throw new RuntimeException("获取用户历史失败: " + e.getMessage());
        }
    }

    @Override
    public List<BlockchainRecord> getBookHistory(Integer bookId) {
        try {
            return blockchainRecordMapper.selectByBookId(bookId);
        } catch (Exception e) {
            log.error("❌ 获取图书历史失败", e);
            throw new RuntimeException("获取图书历史失败: " + e.getMessage());
        }
    }

    /**
     * 计算SHA256哈希
     */
    private String calculateSHA256(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (Exception e) {
            throw new RuntimeException("SHA256计算失败", e);
        }
    }

    /**
     * 写入区块链日志文件
     */
    private void writeToBlockchainFile(BlockchainRecord record) {
        try {
            String logContent = String.format(
                    "【区块记录】ID: %d | 交易ID: %s | 类型: %s | 用户ID: %d | 图书ID: %d | 哈希: %s | 前哈希: %s | 时间: %s%n",
                    record.getId(),
                    record.getTransactionId(),
                    record.getTransactionType(),
                    record.getUserId(),
                    record.getBookId(),
                    record.getBlockHash().substring(0, 16) + "...",
                    record.getPreviousHash().substring(0, 16) + "...",
                    new Date(record.getTimestamp())
            );

            // 写入到项目根目录下的 blockchain.log 文件
            java.nio.file.Files.write(
                    java.nio.file.Paths.get("blockchain.log"),
                    logContent.getBytes(StandardCharsets.UTF_8),
                    java.nio.file.StandardOpenOption.CREATE,
                    java.nio.file.StandardOpenOption.APPEND
            );

        } catch (Exception e) {
            log.warn("⚠️ 写入区块链日志文件失败: {}", e.getMessage());
        }
    }
}