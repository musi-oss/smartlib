// src/main/java/com/smartlib/service/impl/UserServiceImpl.java
package com.smartlib.service.impl;

import com.smartlib.entity.User;
import com.smartlib.mapper.UserMapper;
import com.smartlib.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.DigestUtils;

import java.util.Date;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Override
    @Transactional
    public User register(String username, String password, String email) {
        // 检查用户名是否存在
        if (isUsernameExists(username)) {
            throw new RuntimeException("用户名已存在");
        }

        // 密码加密
        String encryptedPassword = DigestUtils.md5DigestAsHex(password.getBytes());

        User user = new User();
        user.setUsername(username);
        user.setPassword(encryptedPassword);
        user.setEmail(email);
        user.setUserType("STUDENT");
        user.setPoints(0);
        user.setBorrowCount(0);
        user.setCreatedAt(new Date());
        user.setUpdatedAt(new Date());

        userMapper.insert(user);
        return user;
    }

    @Override
    public User login(String username, String password) {
        User user = userMapper.selectByUsername(username);
        if (user == null) {
            throw new RuntimeException("用户不存在");
        }

        String encryptedPassword = DigestUtils.md5DigestAsHex(password.getBytes());
        if (!encryptedPassword.equals(user.getPassword())) {
            throw new RuntimeException("密码错误");
        }

        return user;
    }

    @Override
    public User getUserById(Integer id) {
        return userMapper.selectById(id);
    }

    @Override
    public List<User> getAllUsers() {
        return userMapper.selectAll();
    }

    @Override
    @Transactional
    public User updateUser(User user) {
        User existingUser = userMapper.selectById(user.getId());
        if (existingUser == null) {
            throw new RuntimeException("用户不存在");
        }

        // 更新可修改的字段
        if (user.getEmail() != null) {
            existingUser.setEmail(user.getEmail());
        }
        if (user.getAvatarUrl() != null) {
            existingUser.setAvatarUrl(user.getAvatarUrl());
        }

        existingUser.setUpdatedAt(new Date());
        userMapper.update(existingUser);
        return existingUser;
    }

    @Override
    @Transactional
    public boolean deleteUser(Integer id) {
        return userMapper.delete(id) > 0;
    }

    @Override
    @Transactional
    public boolean changePassword(Integer userId, String oldPassword, String newPassword) {
        User user = userMapper.selectById(userId);
        if (user == null) {
            throw new RuntimeException("用户不存在");
        }

        String encryptedOldPassword = DigestUtils.md5DigestAsHex(oldPassword.getBytes());
        if (!encryptedOldPassword.equals(user.getPassword())) {
            throw new RuntimeException("原密码错误");
        }

        String encryptedNewPassword = DigestUtils.md5DigestAsHex(newPassword.getBytes());
        user.setPassword(encryptedNewPassword);
        user.setUpdatedAt(new Date());

        return userMapper.update(user) > 0;
    }

    @Override
    @Transactional
    public boolean updatePoints(Integer userId, Integer points) {
        User user = userMapper.selectById(userId);
        if (user == null) return false;

        user.setPoints(user.getPoints() + points);
        user.setUpdatedAt(new Date());
        return userMapper.update(user) > 0;
    }

    @Override
    public boolean isUsernameExists(String username) {
        User user = userMapper.selectByUsername(username);
        return user != null;
    }
}