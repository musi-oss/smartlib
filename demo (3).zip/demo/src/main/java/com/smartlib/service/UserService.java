// src/main/java/com/smartlib/service/UserService.java
package com.smartlib.service;

import com.smartlib.entity.User;
import java.util.List;

public interface UserService {

    // 用户注册
    User register(String username, String password, String email);

    // 用户登录
    User login(String username, String password);

    // 获取用户信息
    User getUserById(Integer id);

    // 获取所有用户
    List<User> getAllUsers();

    // 更新用户信息
    User updateUser(User user);

    // 删除用户
    boolean deleteUser(Integer id);

    // 修改密码
    boolean changePassword(Integer userId, String oldPassword, String newPassword);

    // 更新用户积分
    boolean updatePoints(Integer userId, Integer points);

    // 检查用户名是否存在
    boolean isUsernameExists(String username);
}