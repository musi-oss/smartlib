// src/main/java/com/smartlib/service/impl/OCRServiceImpl.java
package com.smartlib.service.impl;

import com.smartlib.entity.Book;
import com.smartlib.service.BookService;
import com.smartlib.service.OCRService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Slf4j
@Service
public class OCRServiceImpl implements OCRService {

    @Value("${baidu.ocr.api-key:}")
    private String apiKey;

    @Value("${baidu.ocr.secret-key:}")
    private String secretKey;

    @Autowired
    private BookService bookService;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public Map<String, Object> recognizeBookInfo(MultipartFile imageFile) {
        try {
            // 1. 获取access_token
            String accessToken = getBaiduAccessToken();

            // 2. 调用百度OCR通用文字识别
            String imageBase64 = Base64.getEncoder().encodeToString(imageFile.getBytes());

            Map<String, Object> params = new HashMap<>();
            params.put("image", imageBase64);
            params.put("language_type", "CHN_ENG");
            params.put("detect_direction", "true");
            params.put("paragraph", "true");

            String result = callBaiduOCR(accessToken, params);

            // 3. 解析OCR结果，提取图书信息
            Map<String, Object> parsedResult = parseOCRResult(result);

            // 4. 记录OCR日志
            logOCRHistory(imageFile.getOriginalFilename(), parsedResult);

            return parsedResult;

        } catch (Exception e) {
            log.error("OCR识别失败", e);
            Map<String, Object> errorResult = new HashMap<>();
            errorResult.put("success", false);
            errorResult.put("error", e.getMessage());
            return errorResult;
        }
    }

    @Override
    public Book createBookFromOCR(MultipartFile imageFile, Integer userId) {
        try {
            // 1. OCR识别
            Map<String, Object> ocrResult = recognizeBookInfo(imageFile);

            if (!Boolean.TRUE.equals(ocrResult.get("success"))) {
                throw new RuntimeException("OCR识别失败: " + ocrResult.get("error"));
            }

            // 2. 创建图书对象
            Book book = new Book();
            book.setTitle((String) ocrResult.getOrDefault("title", "未知图书"));
            book.setAuthor((String) ocrResult.getOrDefault("author", "未知作者"));
            book.setIsbn((String) ocrResult.getOrDefault("isbn", ""));
            book.setCategory((String) ocrResult.getOrDefault("category", "未知分类"));
            book.setDescription((String) ocrResult.getOrDefault("description", ""));
            book.setStock(1);

            // 3. 保存到数据库
            return bookService.addBook(book);

        } catch (Exception e) {
            log.error("从OCR创建图书失败", e);
            throw new RuntimeException("创建图书失败: " + e.getMessage());
        }
    }

    @Override
    public Map<String, Object> getOCRHistory(Integer userId) {
        // 简化实现：实际应该从数据库查询
        Map<String, Object> history = new HashMap<>();
        history.put("totalCount", 0);
        history.put("successCount", 0);
        history.put("recentRecognitions", new ArrayList<>());
        return history;
    }

    // ========== 私有方法 ==========

    private String getBaiduAccessToken() throws IOException {
        if (apiKey.isEmpty() || secretKey.isEmpty()) {
            log.warn("未配置百度OCR API密钥，使用模拟数据");
            return "mock_access_token";
        }

        String url = "https://aip.baidubce.com/oauth/2.0/token";
        String params = "grant_type=client_credentials" +
                "&client_id=" + apiKey +
                "&client_secret=" + secretKey;

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpPost request = new HttpPost(url + "?" + params);
            request.addHeader("Content-Type", "application/json");

            try (CloseableHttpResponse response = httpClient.execute(request)) {
                String responseBody = EntityUtils.toString(response.getEntity());
                Map<String, Object> result = objectMapper.readValue(responseBody, Map.class);
                return (String) result.get("access_token");
            }
        }
    }

    private String callBaiduOCR(String accessToken, Map<String, Object> params) throws IOException {
        if ("mock_access_token".equals(accessToken)) {
            // 返回模拟的OCR结果
            return getMockOCRResult();
        }

        String url = "https://aip.baidubce.com/rest/2.0/ocr/v1/general_basic?access_token=" + accessToken;

        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpPost request = new HttpPost(url);
            request.addHeader("Content-Type", "application/x-www-form-urlencoded");

            StringBuilder formData = new StringBuilder();
            for (Map.Entry<String, Object> entry : params.entrySet()) {
                if (formData.length() > 0) {
                    formData.append("&");
                }
                formData.append(entry.getKey()).append("=").append(entry.getValue());
            }

            request.setEntity(new StringEntity(formData.toString(), StandardCharsets.UTF_8));

            try (CloseableHttpResponse response = httpClient.execute(request)) {
                return EntityUtils.toString(response.getEntity());
            }
        }
    }

    private Map<String, Object> parseOCRResult(String ocrResult) throws IOException {
        Map<String, Object> result = new HashMap<>();

        if (ocrResult.contains("mock")) {
            // 解析模拟数据
            result.put("success", true);
            result.put("title", "Spring Boot实战");
            result.put("author", "张三");
            result.put("isbn", "9787121344567");
            result.put("category", "计算机");
            result.put("description", "Spring Boot入门到实战指南");
            result.put("confidence", 0.95);
            return result;
        }

        // 解析真实的百度OCR返回结果
        Map<String, Object> rawResult = objectMapper.readValue(ocrResult, Map.class);

        if (rawResult.containsKey("error_code")) {
            result.put("success", false);
            result.put("error", rawResult.get("error_msg"));
            return result;
        }

        // 提取文字内容
        List<Map<String, Object>> wordsResult = (List<Map<String, Object>>) rawResult.get("words_result");
        StringBuilder fullText = new StringBuilder();
        for (Map<String, Object> word : wordsResult) {
            fullText.append(word.get("words")).append("\n");
        }

        // 简单的图书信息提取逻辑
        String text = fullText.toString();
        result.put("success", true);
        result.put("fullText", text);
        result.put("title", extractTitle(text));
        result.put("author", extractAuthor(text));
        result.put("isbn", extractISBN(text));
        result.put("category", "计算机"); // 默认分类
        result.put("description", text.length() > 200 ? text.substring(0, 200) + "..." : text);
        result.put("confidence", 0.8);

        return result;
    }

    private String extractTitle(String text) {
        // 简单提取标题逻辑：第一行非空内容
        String[] lines = text.split("\n");
        for (String line : lines) {
            if (line.length() > 3 && line.length() < 50) {
                return line.trim();
            }
        }
        return "未知图书";
    }

    private String extractAuthor(String text) {
        // 查找包含"作者"、"著"、"编"等关键词的行
        String[] lines = text.split("\n");
        for (String line : lines) {
            if (line.contains("作者") || line.contains("著") || line.contains("编")) {
                return line.replace("作者", "").replace("著", "").replace("编", "").trim();
            }
        }
        return "未知作者";
    }

    private String extractISBN(String text) {
        // 提取ISBN号码（13位或10位数字）
        String[] parts = text.split("[\\s\\n]");
        for (String part : parts) {
            String cleaned = part.replaceAll("[^0-9]", "");
            if (cleaned.length() == 10 || cleaned.length() == 13) {
                return cleaned;
            }
        }
        return "";
    }

    private void logOCRHistory(String filename, Map<String, Object> result) {
        log.info("OCR识别记录 - 文件: {}, 结果: {}", filename, result.get("title"));
    }

    private String getMockOCRResult() {
        return "{\"words_result\":[{\"words\":\"Spring Boot实战\"},{\"words\":\"作者：张三\"},{\"words\":\"ISBN：9787121344567\"},{\"words\":\"出版社：电子工业出版社\"},{\"words\":\"本书全面介绍Spring Boot开发技术\"}],\"words_result_num\":5,\"log_id\":123456789}";
    }
}