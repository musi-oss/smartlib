// src/main/java/com/smartlib/service/BookService.java
package com.smartlib.service;

import com.smartlib.entity.Book;
import java.util.List;

public interface BookService {

    // 添加图书
    Book addBook(Book book);

    // 更新图书
    Book updateBook(Book book);

    // 删除图书
    boolean deleteBook(Integer id);

    // 根据ID获取图书
    Book getBookById(Integer id);

    // 获取所有图书
    List<Book> getAllBooks();

    // 搜索图书
    List<Book> searchBooks(String keyword);

    // 根据分类获取图书
    List<Book> getBooksByCategory(String category);

    // 减少库存
    boolean decreaseStock(Integer bookId, Integer quantity);

    // 增加库存
    boolean increaseStock(Integer bookId, Integer quantity);

    // 获取热门图书
    List<Book> getPopularBooks(Integer limit);

    // 获取推荐图书
    List<Book> getRecommendedBooks(Integer userId);
}
