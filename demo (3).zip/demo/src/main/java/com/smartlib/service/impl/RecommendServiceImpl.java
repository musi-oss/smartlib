// src/main/java/com/smartlib/service/impl/RecommendServiceImpl.java
package com.smartlib.service.impl;

import com.smartlib.entity.Book;
import com.smartlib.entity.BorrowRecord;
import com.smartlib.mapper.BookMapper;
import com.smartlib.mapper.BorrowRecordMapper;
import com.smartlib.service.BookService;
import com.smartlib.service.RecommendService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class RecommendServiceImpl implements RecommendService {

    @Autowired
    private BookMapper bookMapper;

    @Autowired
    private BorrowRecordMapper borrowRecordMapper;

    @Autowired
    private BookService bookService;

    // 用户行为记录（实际项目中应该用Redis或数据库）
    private Map<Integer, Map<Integer, String>> userActions = new HashMap<>();

    @Override
    public List<Book> recommendByUserCF(Integer userId, Integer limit) {
        try {
            // 1. 获取所有用户的借阅记录
            List<BorrowRecord> allRecords = borrowRecordMapper.selectAll();

            // 2. 构建用户-图书矩阵
            Map<Integer, Set<Integer>> userBookMatrix = new HashMap<>();
            for (BorrowRecord record : allRecords) {
                userBookMatrix
                        .computeIfAbsent(record.getUserId(), k -> new HashSet<>())
                        .add(record.getBookId());
            }

            // 3. 计算用户相似度（简化版：共同借阅数量）
            Map<Integer, Double> userSimilarities = new HashMap<>();
            Set<Integer> targetUserBooks = userBookMatrix.getOrDefault(userId, new HashSet<>());

            for (Map.Entry<Integer, Set<Integer>> entry : userBookMatrix.entrySet()) {
                if (entry.getKey().equals(userId)) continue;

                Set<Integer> otherUserBooks = entry.getValue();
                // 计算Jaccard相似度
                Set<Integer> intersection = new HashSet<>(targetUserBooks);
                intersection.retainAll(otherUserBooks);

                Set<Integer> union = new HashSet<>(targetUserBooks);
                union.addAll(otherUserBooks);

                double similarity = union.isEmpty() ? 0 :
                        (double) intersection.size() / union.size();
                userSimilarities.put(entry.getKey(), similarity);
            }

            // 4. 找出最相似的K个用户
            List<Map.Entry<Integer, Double>> sortedSimilarities = userSimilarities.entrySet()
                    .stream()
                    .sorted((a, b) -> Double.compare(b.getValue(), a.getValue()))
                    .limit(5)
                    .collect(Collectors.toList());

            // 5. 推荐相似用户喜欢但目标用户没看过的图书
            Set<Integer> recommendedBookIds = new HashSet<>();
            for (Map.Entry<Integer, Double> entry : sortedSimilarities) {
                Set<Integer> similarUserBooks = userBookMatrix.get(entry.getKey());
                if (similarUserBooks != null) {
                    for (Integer bookId : similarUserBooks) {
                        if (!targetUserBooks.contains(bookId)) {
                            recommendedBookIds.add(bookId);
                        }
                    }
                }
            }

            // 6. 获取图书详情
            return getBooksByIds(new ArrayList<>(recommendedBookIds), limit);

        } catch (Exception e) {
            log.error("基于用户的协同过滤推荐失败", e);
            return recommendHot(limit); // 失败时返回热门推荐
        }
    }

    @Override
    public List<Book> recommendByItemCF(Integer userId, Integer limit) {
        // 简化实现：基于用户历史借阅，推荐相似图书
        try {
            // 1. 获取用户借阅历史
            List<BorrowRecord> userRecords = borrowRecordMapper.selectByUserId(userId);
            if (userRecords.isEmpty()) {
                return recommendHot(limit);
            }

            // 2. 获取用户借阅过的图书
            Set<Integer> userBorrowedBooks = userRecords.stream()
                    .map(BorrowRecord::getBookId)
                    .collect(Collectors.toSet());

            // 3. 基于标签相似度推荐（简化版）
            List<Book> allBooks = bookMapper.selectAll();
            Map<Integer, Double> bookScores = new HashMap<>();

            for (Book book : allBooks) {
                if (userBorrowedBooks.contains(book.getId())) {
                    continue; // 跳过已经借阅过的
                }

                double score = calculateBookSimilarity(userBorrowedBooks, book);
                if (score > 0) {
                    bookScores.put(book.getId(), score);
                }
            }

            // 4. 按评分排序
            List<Integer> recommendedIds = bookScores.entrySet().stream()
                    .sorted((a, b) -> Double.compare(b.getValue(), a.getValue()))
                    .limit(limit != null ? limit : 10)
                    .map(Map.Entry::getKey)
                    .collect(Collectors.toList());

            return getBooksByIds(recommendedIds, limit);

        } catch (Exception e) {
            log.error("基于物品的协同过滤推荐失败", e);
            return recommendHot(limit);
        }
    }

    @Override
    public List<Book> recommendByContent(Integer userId, Integer limit) {
        try {
            // 1. 获取用户借阅历史
            List<BorrowRecord> userRecords = borrowRecordMapper.selectByUserId(userId);
            if (userRecords.isEmpty()) {
                return recommendHot(limit);
            }

            // 2. 提取用户偏好标签
            Set<String> userPreferences = new HashSet<>();
            for (BorrowRecord record : userRecords) {
                Book book = bookMapper.selectById(record.getBookId());
                if (book != null && book.getTags() != null) {
                    String[] tags = book.getTags().split(",");
                    userPreferences.addAll(Arrays.asList(tags));
                }
            }

            // 3. 推荐具有相似标签的图书
            List<Book> allBooks = bookMapper.selectAll();
            Map<Integer, Integer> tagMatchCount = new HashMap<>();

            for (Book book : allBooks) {
                if (book.getTags() == null) continue;

                int matches = 0;
                String[] bookTags = book.getTags().split(",");
                for (String tag : bookTags) {
                    if (userPreferences.contains(tag.trim())) {
                        matches++;
                    }
                }

                if (matches > 0) {
                    tagMatchCount.put(book.getId(), matches);
                }
            }

            // 4. 按匹配数量排序
            List<Integer> recommendedIds = tagMatchCount.entrySet().stream()
                    .sorted((a, b) -> Integer.compare(b.getValue(), a.getValue()))
                    .limit(limit != null ? limit : 10)
                    .map(Map.Entry::getKey)
                    .collect(Collectors.toList());

            return getBooksByIds(recommendedIds, limit);

        } catch (Exception e) {
            log.error("基于内容的推荐失败", e);
            return recommendHot(limit);
        }
    }

    @Override
    public List<Book> recommendHot(Integer limit) {
        return bookService.getPopularBooks(limit);
    }

    @Override
    public List<Book> recommendNew(Integer limit) {
        List<Book> allBooks = bookMapper.selectAll();
        // 按创建时间倒序
        allBooks.sort((b1, b2) -> b2.getCreatedAt().compareTo(b1.getCreatedAt()));
        return allBooks.stream()
                .limit(limit != null ? limit : 10)
                .collect(Collectors.toList());
    }

    @Override
    public List<Book> recommendHybrid(Integer userId, Integer limit) {
        // 混合推荐策略：加权综合多种算法
        List<Book> userCFResults = recommendByUserCF(userId, limit * 2);
        List<Book> itemCFResults = recommendByItemCF(userId, limit * 2);
        List<Book> contentResults = recommendByContent(userId, limit * 2);
        List<Book> hotResults = recommendHot(limit);

        // 合并并去重
        Set<Integer> seenIds = new HashSet<>();
        List<Book> combined = new ArrayList<>();

        // 按优先级添加
        addUniqueBooks(combined, userCFResults, seenIds, limit);
        addUniqueBooks(combined, itemCFResults, seenIds, limit - combined.size());
        addUniqueBooks(combined, contentResults, seenIds, limit - combined.size());

        // 如果还不够，用热门推荐补足
        if (combined.size() < limit) {
            addUniqueBooks(combined, hotResults, seenIds, limit - combined.size());
        }

        return combined;
    }

    @Override
    public Map<String, Object> getRecommendationReason(Integer userId, Integer bookId) {
        Map<String, Object> reason = new HashMap<>();
        reason.put("bookId", bookId);
        reason.put("userId", userId);

        // 模拟推荐理由
        List<String> possibleReasons =Arrays.asList(
                "与您借阅过的图书标签相似",
                "其他类似用户也喜欢这本书",
                "这本书最近很热门",
                "根据您的阅读历史推荐",
                "新上架的好书"
        );

        Random random = new Random();
        reason.put("reason", possibleReasons.get(random.nextInt(possibleReasons.size())));
        reason.put("confidence", random.nextDouble() * 0.5 + 0.5); // 0.5-1.0

        return reason;
    }

    @Override
    public void recordUserAction(Integer userId, Integer bookId, String actionType) {
        // 记录用户行为
        userActions
                .computeIfAbsent(userId, k -> new HashMap<>())
                .put(bookId, actionType);
        log.info("记录用户行为: userId={}, bookId={}, action={}", userId, bookId, actionType);
    }

    // ========== 私有方法 ==========

    private List<Book> getBooksByIds(List<Integer> bookIds, Integer limit) {
        if (bookIds.isEmpty()) {
            return new ArrayList<>();
        }

        List<Book> result = new ArrayList<>();
        for (Integer bookId : bookIds) {
            Book book = bookMapper.selectById(bookId);
            if (book != null) {
                result.add(book);
                if (limit != null && result.size() >= limit) {
                    break;
                }
            }
        }
        return result;
    }

    private double calculateBookSimilarity(Set<Integer> userBorrowedBooks, Book targetBook) {
        // 简化版相似度计算：基于标签匹配
        if (targetBook.getTags() == null) return 0;

        double maxSimilarity = 0;
        for (Integer borrowedBookId : userBorrowedBooks) {
            Book borrowedBook = bookMapper.selectById(borrowedBookId);
            if (borrowedBook == null || borrowedBook.getTags() == null) continue;

            double similarity = calculateTagSimilarity(
                    borrowedBook.getTags(), targetBook.getTags());
            maxSimilarity = Math.max(maxSimilarity, similarity);
        }

        return maxSimilarity;
    }

    private double calculateTagSimilarity(String tags1, String tags2) {
        if (tags1 == null || tags2 == null) return 0;

        Set<String> set1 = new HashSet<>(Arrays.asList(tags1.split(",")));
        Set<String> set2 = new HashSet<>(Arrays.asList(tags2.split(",")));

        Set<String> intersection = new HashSet<>(set1);
        intersection.retainAll(set2);

        Set<String> union = new HashSet<>(set1);
        union.addAll(set2);

        return union.isEmpty() ? 0 : (double) intersection.size() / union.size();
    }

    private void addUniqueBooks(List<Book> target, List<Book> source,
                                Set<Integer> seenIds, int maxToAdd) {
        for (Book book : source) {
            if (seenIds.add(book.getId())) {
                target.add(book);
                if (target.size() >= maxToAdd) {
                    break;
                }
            }
        }
    }
}