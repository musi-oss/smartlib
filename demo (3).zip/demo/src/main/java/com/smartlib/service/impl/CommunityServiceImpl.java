// src/main/java/com/smartlib/service/impl/CommunityServiceImpl.java
package com.smartlib.service.impl;

import com.smartlib.entity.CommunityPost;
import com.smartlib.entity.CommunityComment;
import com.smartlib.mapper.CommunityPostMapper;
import com.smartlib.mapper.CommunityCommentMapper;
import com.smartlib.service.CommunityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class CommunityServiceImpl implements CommunityService {

    @Autowired
    private CommunityPostMapper postMapper;

    @Autowired
    private CommunityCommentMapper commentMapper;

    // 记录用户点赞状态（实际项目中应该用Redis）
    private Map<String, Boolean> postLikes = new HashMap<>();
    private Map<String, Boolean> commentLikes = new HashMap<>();

    @Override
    @Transactional
    public CommunityPost createPost(CommunityPost post) {
        post.setCreateTime(new Date());
        post.setUpdateTime(new Date());
        post.setStatus("PUBLISHED");
        post.setViewCount(0);
        post.setLikeCount(0);
        post.setCommentCount(0);

        postMapper.insert(post);
        return post;
    }

    @Override
    @Transactional
    public CommunityPost updatePost(CommunityPost post) {
        CommunityPost existingPost = postMapper.selectById(post.getId());
        if (existingPost == null || !existingPost.getUserId().equals(post.getUserId())) {
            throw new RuntimeException("无权修改此帖子");
        }

        existingPost.setTitle(post.getTitle());
        existingPost.setContent(post.getContent());
        existingPost.setPostType(post.getPostType());
        existingPost.setTags(post.getTags());
        existingPost.setUpdateTime(new Date());

        postMapper.update(existingPost);
        return existingPost;
    }

    @Override
    @Transactional
    public boolean deletePost(Integer postId, Integer userId) {
        CommunityPost post = postMapper.selectById(postId);
        if (post == null || !post.getUserId().equals(userId)) {
            return false;
        }
        return postMapper.delete(postId) > 0;
    }

    @Override
    public CommunityPost getPostById(Integer id) {
        CommunityPost post = postMapper.selectById(id);
        if (post != null) {
            // 增加浏览量
            postMapper.increaseViewCount(id);
            post.setViewCount(post.getViewCount() + 1);
        }
        return post;
    }

    @Override
    public List<CommunityPost> getAllPosts() {
        return postMapper.selectAll();
    }

    @Override
    public List<CommunityPost> getPostsByUser(Integer userId) {
        return postMapper.selectByUserId(userId);
    }

    @Override
    public List<CommunityPost> getPostsByType(String postType) {
        return postMapper.selectByType(postType);
    }

    @Override
    public List<CommunityPost> searchPosts(String keyword) {
        return postMapper.search(keyword);
    }

    @Override
    public List<CommunityPost> getPopularPosts(Integer limit) {
        return postMapper.selectPopular(limit == null ? 10 : limit);
    }

    @Override
    @Transactional
    public boolean likePost(Integer postId, Integer userId) {
        String key = postId + "_" + userId;
        if (postLikes.containsKey(key) && postLikes.get(key)) {
            return false; // 已经点赞过了
        }

        postMapper.updateLikeCount(postId, 1);
        postLikes.put(key, true);
        return true;
    }

    @Override
    @Transactional
    public boolean unlikePost(Integer postId, Integer userId) {
        String key = postId + "_" + userId;
        if (!postLikes.containsKey(key) || !postLikes.get(key)) {
            return false; // 没有点赞记录
        }

        postMapper.updateLikeCount(postId, -1);
        postLikes.put(key, false);
        return true;
    }

    @Override
    @Transactional
    public CommunityComment createComment(CommunityComment comment) {
        commentMapper.insert(comment);

        // 更新帖子的评论数
        postMapper.updateCommentCount(comment.getPostId(), 1);

        return comment;
    }

    @Override
    @Transactional
    public CommunityComment updateComment(CommunityComment comment) {
        CommunityComment existingComment = commentMapper.selectById(comment.getId());
        if (existingComment == null || !existingComment.getUserId().equals(comment.getUserId())) {
            throw new RuntimeException("无权修改此评论");
        }

        existingComment.setContent(comment.getContent());
        commentMapper.update(existingComment);
        return existingComment;
    }

    @Override
    @Transactional
    public boolean deleteComment(Integer commentId, Integer userId) {
        CommunityComment comment = commentMapper.selectById(commentId);
        if (comment == null || !comment.getUserId().equals(userId)) {
            return false;
        }

        commentMapper.delete(commentId);

        // 更新帖子的评论数
        postMapper.updateCommentCount(comment.getPostId(), -1);

        return true;
    }

    @Override
    public List<CommunityComment> getCommentsByPost(Integer postId) {
        return commentMapper.selectByPostId(postId);
    }

    @Override
    public List<CommunityComment> getCommentsByUser(Integer userId) {
        return commentMapper.selectByUserId(userId);
    }

    @Override
    @Transactional
    public boolean likeComment(Integer commentId, Integer userId) {
        String key = commentId + "_" + userId;
        if (commentLikes.containsKey(key) && commentLikes.get(key)) {
            return false;
        }

        commentMapper.updateLikeCount(commentId, 1);
        commentLikes.put(key, true);
        return true;
    }

    @Override
    public Integer getUserPostCount(Integer userId) {
        return postMapper.selectByUserId(userId).size();
    }

    @Override
    public Integer getUserCommentCount(Integer userId) {
        return commentMapper.selectByUserId(userId).size();
    }
}