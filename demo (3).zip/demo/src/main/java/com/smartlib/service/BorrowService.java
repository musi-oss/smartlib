// src/main/java/com/smartlib/service/BorrowService.java
package com.smartlib.service;

import com.smartlib.entity.BorrowRecord;
import java.util.List;

public interface BorrowService {

    // 借阅图书
    BorrowRecord borrowBook(Integer userId, Integer bookId, Integer borrowDays);

    // 归还图书
    BorrowRecord returnBook(Integer borrowRecordId, String condition);

    // 续借图书
    BorrowRecord renewBook(Integer borrowRecordId, Integer extraDays);

    // 获取借阅记录
    BorrowRecord getBorrowRecord(Integer id);

    // 获取用户借阅历史
    List<BorrowRecord> getUserBorrowHistory(Integer userId);

    // 获取图书借阅历史
    List<BorrowRecord> getBookBorrowHistory(Integer bookId);

    // 获取当前借阅中的图书
    List<BorrowRecord> getBorrowingRecords(Integer userId);

    // 获取所有借阅记录
    List<BorrowRecord> getAllBorrowRecords();

    // 检查逾期记录
    List<BorrowRecord> checkOverdueRecords();

    // 计算逾期罚金
    Double calculatePenalty(Integer borrowRecordId);
}