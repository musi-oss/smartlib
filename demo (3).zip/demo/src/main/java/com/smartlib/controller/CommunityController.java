// src/main/java/com/smartlib/controller/CommunityController.java
package com.smartlib.controller;

import com.smartlib.common.Result;
import com.smartlib.entity.CommunityPost;
import com.smartlib.entity.CommunityComment;
import com.smartlib.service.CommunityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/community")
@CrossOrigin(origins = "*")
public class CommunityController extends BaseController {

    @Autowired
    private CommunityService communityService;

    // ========== 帖子相关接口 ==========

    @PostMapping("/post/create")
    public Result<CommunityPost> createPost(@RequestBody CommunityPost post) {
        try {
            CommunityPost createdPost = communityService.createPost(post);
            return Result.success(createdPost);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @PutMapping("/post/update")
    public Result<CommunityPost> updatePost(@RequestBody CommunityPost post) {
        try {
            CommunityPost updatedPost = communityService.updatePost(post);
            return Result.success(updatedPost);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @DeleteMapping("/post/delete")
    public Result<Boolean> deletePost(
            @RequestParam Integer postId,
            @RequestParam Integer userId) {
        try {
            boolean success = communityService.deletePost(postId, userId);
            return Result.success(success);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/post/{id}")
    public Result<CommunityPost> getPostById(@PathVariable Integer id) {
        try {
            CommunityPost post = communityService.getPostById(id);
            return Result.success(post);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/post/all")
    public Result<List<CommunityPost>> getAllPosts() {
        try {
            List<CommunityPost> posts = communityService.getAllPosts();
            return Result.success(posts);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/post/user/{userId}")
    public Result<List<CommunityPost>> getPostsByUser(@PathVariable Integer userId) {
        try {
            List<CommunityPost> posts = communityService.getPostsByUser(userId);
            return Result.success(posts);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/post/type/{postType}")
    public Result<List<CommunityPost>> getPostsByType(@PathVariable String postType) {
        try {
            List<CommunityPost> posts = communityService.getPostsByType(postType);
            return Result.success(posts);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/post/search")
    public Result<List<CommunityPost>> searchPosts(@RequestParam String keyword) {
        try {
            List<CommunityPost> posts = communityService.searchPosts(keyword);
            return Result.success(posts);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/post/popular")
    public Result<List<CommunityPost>> getPopularPosts(@RequestParam(defaultValue = "10") Integer limit) {
        try {
            List<CommunityPost> posts = communityService.getPopularPosts(limit);
            return Result.success(posts);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @PostMapping("/post/like")
    public Result<Boolean> likePost(
            @RequestParam Integer postId,
            @RequestParam Integer userId) {
        try {
            boolean success = communityService.likePost(postId, userId);
            return Result.success(success);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @PostMapping("/post/unlike")
    public Result<Boolean> unlikePost(
            @RequestParam Integer postId,
            @RequestParam Integer userId) {
        try {
            boolean success = communityService.unlikePost(postId, userId);
            return Result.success(success);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    // ========== 评论相关接口 ==========

    @PostMapping("/comment/create")
    public Result<CommunityComment> createComment(@RequestBody CommunityComment comment) {
        try {
            CommunityComment createdComment = communityService.createComment(comment);
            return Result.success(createdComment);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @PutMapping("/comment/update")
    public Result<CommunityComment> updateComment(@RequestBody CommunityComment comment) {
        try {
            CommunityComment updatedComment = communityService.updateComment(comment);
            return Result.success(updatedComment);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @DeleteMapping("/comment/delete")
    public Result<Boolean> deleteComment(
            @RequestParam Integer commentId,
            @RequestParam Integer userId) {
        try {
            boolean success = communityService.deleteComment(commentId, userId);
            return Result.success(success);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/comment/post/{postId}")
    public Result<List<CommunityComment>> getCommentsByPost(@PathVariable Integer postId) {
        try {
            List<CommunityComment> comments = communityService.getCommentsByPost(postId);
            return Result.success(comments);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/comment/user/{userId}")
    public Result<List<CommunityComment>> getCommentsByUser(@PathVariable Integer userId) {
        try {
            List<CommunityComment> comments = communityService.getCommentsByUser(userId);
            return Result.success(comments);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @PostMapping("/comment/like")
    public Result<Boolean> likeComment(
            @RequestParam Integer commentId,
            @RequestParam Integer userId) {
        try {
            boolean success = communityService.likeComment(commentId, userId);
            return Result.success(success);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    // ========== 统计接口 ==========

    @GetMapping("/stats/user/{userId}")
    public Result<Object> getUserStats(@PathVariable Integer userId) {
        try {
            final Integer postCountValue = communityService.getUserPostCount(userId);
            final Integer commentCountValue = communityService.getUserCommentCount(userId);

            return Result.success(new Object() {
                public Integer postCount = postCountValue;       // 使用重命名的变量
                public Integer commentCount = commentCountValue;
                public Integer totalActivity = postCountValue + commentCountValue;
            });
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
}