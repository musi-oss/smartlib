// src/main/java/com/smartlib/controller/BlockchainController.java
package com.smartlib.controller;

import com.smartlib.common.Result;
import com.smartlib.entity.BlockchainRecord;
import com.smartlib.service.BlockchainService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/blockchain")
@CrossOrigin(origins = "*") // 允许前端跨域访问
public class BlockchainController extends BaseController {

    @Autowired
    private BlockchainService blockchainService;

    /**
     * 创建借阅交易
     */
    @PostMapping("/borrow")
    public Result<BlockchainRecord> createBorrowTransaction(
            @RequestParam Integer userId,
            @RequestParam Integer bookId,
            @RequestParam(required = false) String bookTitle,
            @RequestParam(defaultValue = "30") Integer borrowDays) {

        String title = bookTitle != null ? bookTitle : "未知图书";
        BlockchainRecord record = blockchainService.createBorrowTransaction(
                userId, bookId, borrowDays, title);
        return Result.success(record);
    }

    /**
     * 创建归还交易
     */
    @PostMapping("/return")
    public Result<BlockchainRecord> createReturnTransaction(
            @RequestParam Integer userId,
            @RequestParam Integer bookId,
            @RequestParam(required = false) String bookTitle,
            @RequestParam(defaultValue = "完好") String condition) {

        String title = bookTitle != null ? bookTitle : "未知图书";
        BlockchainRecord record = blockchainService.createReturnTransaction(
                userId, bookId, condition, title);
        return Result.success(record);
    }

    /**
     * 创建转让交易
     */
    @PostMapping("/transfer")
    public Result<BlockchainRecord> createTransferTransaction(
            @RequestParam Integer fromUserId,
            @RequestParam Integer toUserId,
            @RequestParam Integer bookId,
            @RequestParam(required = false) String bookTitle,
            @RequestParam(defaultValue = "0.0") Double price) {

        String title = bookTitle != null ? bookTitle : "未知图书";
        BlockchainRecord record = blockchainService.createTransferTransaction(
                fromUserId, toUserId, bookId, price, title);
        return Result.success(record);
    }

    /**
     * 获取完整区块链
     */
    @GetMapping("/chain")
    public Result<List<BlockchainRecord>> getBlockchain() {
        List<BlockchainRecord> chain = blockchainService.getBlockchain();
        return Result.success(chain);
    }

    /**
     * 验证区块链完整性
     */
    @GetMapping("/validate")
    public Result<Boolean> validateChain() {
        boolean isValid = blockchainService.validateChain();
        return Result.success(isValid);
    }

    /**
     * 获取用户交易历史
     */
    @GetMapping("/user/{userId}")
    public Result<List<BlockchainRecord>> getUserHistory(@PathVariable Integer userId) {
        List<BlockchainRecord> history = blockchainService.getUserHistory(userId);
        return Result.success(history);
    }

    /**
     * 获取图书交易历史
     */
    @GetMapping("/book/{bookId}")
    public Result<List<BlockchainRecord>> getBookHistory(@PathVariable Integer bookId) {
        List<BlockchainRecord> history = blockchainService.getBookHistory(bookId);
        return Result.success(history);
    }

    /**
     * 获取区块链统计信息
     */
    @GetMapping("/stats")
    public Result<Object> getStats() {
        List<BlockchainRecord> chain = blockchainService.getBlockchain();
        boolean isValid = blockchainService.validateChain();

        long borrowCount = chain.stream()
                .filter(r -> "BORROW".equals(r.getTransactionType()))
                .count();

        long returnCount = chain.stream()
                .filter(r -> "RETURN".equals(r.getTransactionType()))
                .count();

        long transferCount = chain.stream()
                .filter(r -> "TRANSFER".equals(r.getTransactionType()))
                .count();

        return Result.success(new Object() {
            public int totalBlocks = chain.size();
            public boolean valid = isValid;
            public long borrows = borrowCount;
            public long returns = returnCount;
            public long transfers = transferCount;
            public String lastUpdate = chain.isEmpty() ? null :
                    new java.util.Date(chain.get(chain.size() - 1).getTimestamp()).toString();
        });
    }

    /**
     * 测试接口
     */
    @GetMapping("/test")
    public Result<String> test() {
        // 创建一个测试交易
        blockchainService.createBorrowTransaction(1, 1, 30, "测试图书");
        return Result.success("区块链模块测试成功！请查看/blockchain/chain验证");
    }
}