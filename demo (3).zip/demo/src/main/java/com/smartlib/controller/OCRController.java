// src/main/java/com/smartlib/controller/OCRController.java
package com.smartlib.controller;

import com.smartlib.common.Result;
import com.smartlib.entity.Book;
import com.smartlib.service.OCRService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/ocr")
@CrossOrigin(origins = "*")
public class OCRController extends BaseController {

    @Autowired
    private OCRService ocrService;

    @PostMapping("/recognize")
    public Result<Map<String, Object>> recognizeBook(@RequestParam("image") MultipartFile imageFile) {
        try {
            if (imageFile.isEmpty()) {
                return Result.error("请选择图片文件");
            }

            // 检查文件类型
            String contentType = imageFile.getContentType();
            if (contentType == null ||
                    (!contentType.startsWith("image/") && !contentType.equals("application/octet-stream"))) {
                return Result.error("请上传图片文件（支持JPG、PNG等格式）");
            }

            // 检查文件大小（限制5MB）
            if (imageFile.getSize() > 5 * 1024 * 1024) {
                return Result.error("图片大小不能超过5MB");
            }

            Map<String, Object> result = ocrService.recognizeBookInfo(imageFile);
            return Result.success(result);

        } catch (Exception e) {
            return Result.error("识别失败: " + e.getMessage());
        }
    }

    @PostMapping("/create-book")
    public Result<Book> createBookFromOCR(
            @RequestParam("image") MultipartFile imageFile,
            @RequestParam Integer userId) {
        try {
            if (imageFile.isEmpty()) {
                return Result.error("请选择图片文件");
            }

            Book book = ocrService.createBookFromOCR(imageFile, userId);
            return Result.success(book);

        } catch (Exception e) {
            return Result.error("创建图书失败: " + e.getMessage());
        }
    }

    @GetMapping("/history/{userId}")
    public Result<Map<String, Object>> getOCRHistory(@PathVariable Integer userId) {
        try {
            Map<String, Object> history = ocrService.getOCRHistory(userId);
            return Result.success(history);
        } catch (Exception e) {
            return Result.error("获取历史记录失败: " + e.getMessage());
        }
    }

    @GetMapping("/test")
    public Result<String> testOCR() {
        return Result.success("OCR模块运行正常，请上传图片测试");
    }

    @PostMapping("/simple-upload")
    public Result<Map<String, Object>> simpleUpload(@RequestParam("file") MultipartFile file) {
        try {
            // 模拟OCR识别结果（用于前端测试）
            Map<String, Object> mockResult = new HashMap<>();
            mockResult.put("success", true);
            mockResult.put("title", "Spring Boot实战（测试）");
            mockResult.put("author", "张三");
            mockResult.put("isbn", "9787121344567");
            mockResult.put("category", "计算机");
            mockResult.put("description", "这是一本关于Spring Boot开发的图书");
            mockResult.put("fileName", file.getOriginalFilename());
            mockResult.put("fileSize", file.getSize());
            mockResult.put("message", "OCR识别成功（模拟数据）");

            return Result.success(mockResult);
        } catch (Exception e) {
            return Result.error("上传失败：" + e.getMessage());
        }
    }
}