// src/main/java/com/smartlib/controller/BorrowController.java
package com.smartlib.controller;

import com.smartlib.common.Result;
import com.smartlib.entity.BorrowRecord;
import com.smartlib.service.BorrowService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/borrow")
@CrossOrigin(origins = "*")
public class BorrowController extends BaseController {

    @Autowired
    private BorrowService borrowService;

    @PostMapping("/borrow")
    public Result<BorrowRecord> borrowBook(
            @RequestParam Integer userId,
            @RequestParam Integer bookId,
            @RequestParam(defaultValue = "30") Integer borrowDays) {
        try {
            BorrowRecord record = borrowService.borrowBook(userId, bookId, borrowDays);
            return Result.success(record);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @PostMapping("/return")
    public Result<BorrowRecord> returnBook(
            @RequestParam Integer borrowRecordId,
            @RequestParam(defaultValue = "完好") String condition) {
        try {
            BorrowRecord record = borrowService.returnBook(borrowRecordId, condition);
            return Result.success(record);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @PostMapping("/renew")
    public Result<BorrowRecord> renewBook(
            @RequestParam Integer borrowRecordId,
            @RequestParam(defaultValue = "7") Integer extraDays) {
        try {
            BorrowRecord record = borrowService.renewBook(borrowRecordId, extraDays);
            return Result.success(record);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/record/{id}")
    public Result<BorrowRecord> getBorrowRecord(@PathVariable Integer id) {
        try {
            BorrowRecord record = borrowService.getBorrowRecord(id);
            return Result.success(record);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/user/{userId}")
    public Result<List<BorrowRecord>> getUserBorrowHistory(@PathVariable Integer userId) {
        try {
            List<BorrowRecord> records = borrowService.getUserBorrowHistory(userId);
            return Result.success(records);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/book/{bookId}")
    public Result<List<BorrowRecord>> getBookBorrowHistory(@PathVariable Integer bookId) {
        try {
            List<BorrowRecord> records = borrowService.getBookBorrowHistory(bookId);
            return Result.success(records);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/borrowing/{userId}")
    public Result<List<BorrowRecord>> getBorrowingRecords(@PathVariable Integer userId) {
        try {
            List<BorrowRecord> records = borrowService.getBorrowingRecords(userId);
            return Result.success(records);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/all")
    public Result<List<BorrowRecord>> getAllBorrowRecords() {
        try {
            List<BorrowRecord> records = borrowService.getAllBorrowRecords();
            return Result.success(records);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/overdue")
    public Result<List<BorrowRecord>> checkOverdueRecords() {
        try {
            List<BorrowRecord> records = borrowService.checkOverdueRecords();
            return Result.success(records);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/penalty/{borrowRecordId}")
    public Result<Double> calculatePenalty(@PathVariable Integer borrowRecordId) {
        try {
            Double penalty = borrowService.calculatePenalty(borrowRecordId);
            return Result.success(penalty);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    // BorrowController.java
    @GetMapping("/stats/{userId}")
    public Result<Object> getBorrowStats(@PathVariable Integer userId) {
        try {
            List<BorrowRecord> allRecords = borrowService.getUserBorrowHistory(userId);
            final long total = allRecords.size();
            final long borrowing = allRecords.stream()
                    .filter(r -> "BORROWED".equals(r.getStatus()))
                    .count();
            final long overdue = allRecords.stream()
                    .filter(r -> r.getOverdueDays() != null && r.getOverdueDays() > 0)
                    .count();

            return Result.success(new Object() {
                public long totalBorrowed = total;      // 使用不同的变量名
                public long currentlyBorrowing = borrowing;
                public long overdueCount = overdue;
                public int maxAllowed = 5;
            });
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
}