// src/main/java/com/smartlib/controller/RecommendController.java
package com.smartlib.controller;

import com.smartlib.common.Result;
import com.smartlib.entity.Book;
import com.smartlib.service.RecommendService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/recommend")
@CrossOrigin(origins = "*")
public class RecommendController extends BaseController {

    @Autowired
    private RecommendService recommendService;

    @GetMapping("/user/{userId}")
    public Result<List<Book>> recommendByUser(
            @PathVariable Integer userId,
            @RequestParam(defaultValue = "10") Integer limit) {
        try {
            List<Book> books = recommendService.recommendByUserCF(userId, limit);
            return Result.success(books);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/item/{userId}")
    public Result<List<Book>> recommendByItem(
            @PathVariable Integer userId,
            @RequestParam(defaultValue = "10") Integer limit) {
        try {
            List<Book> books = recommendService.recommendByItemCF(userId, limit);
            return Result.success(books);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/content/{userId}")
    public Result<List<Book>> recommendByContent(
            @PathVariable Integer userId,
            @RequestParam(defaultValue = "10") Integer limit) {
        try {
            List<Book> books = recommendService.recommendByContent(userId, limit);
            return Result.success(books);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/hot")
    public Result<List<Book>> recommendHot(@RequestParam(defaultValue = "10") Integer limit) {
        try {
            List<Book> books = recommendService.recommendHot(limit);
            return Result.success(books);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/new")
    public Result<List<Book>> recommendNew(@RequestParam(defaultValue = "10") Integer limit) {
        try {
            List<Book> books = recommendService.recommendNew(limit);
            return Result.success(books);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/hybrid/{userId}")
    public Result<List<Book>> recommendHybrid(
            @PathVariable Integer userId,
            @RequestParam(defaultValue = "10") Integer limit) {
        try {
            List<Book> books = recommendService.recommendHybrid(userId, limit);
            return Result.success(books);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/reason/{userId}/{bookId}")
    public Result<Map<String, Object>> getRecommendationReason(
            @PathVariable Integer userId,
            @PathVariable Integer bookId) {
        try {
            Map<String, Object> reason = recommendService.getRecommendationReason(userId, bookId);
            return Result.success(reason);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @PostMapping("/record-action")
    public Result<Boolean> recordUserAction(
            @RequestParam Integer userId,
            @RequestParam Integer bookId,
            @RequestParam String actionType) {
        try {
            recommendService.recordUserAction(userId, bookId, actionType);
            return Result.success(true);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/test/{userId}")
    public Result<Map<String, Object>> testRecommendation(@PathVariable Integer userId) {
        try {
            Map<String, Object> result = new HashMap<>();
            result.put("userId", userId);
            result.put("userCF", recommendService.recommendByUserCF(userId, 5).size());
            result.put("itemCF", recommendService.recommendByItemCF(userId, 5).size());
            result.put("contentBased", recommendService.recommendByContent(userId, 5).size());
            result.put("hybrid", recommendService.recommendHybrid(userId, 18).size());
            result.put("message", "推荐系统测试成功");

            return Result.success(result);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
}