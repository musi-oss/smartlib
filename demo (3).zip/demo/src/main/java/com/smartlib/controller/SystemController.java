// src/main/java/com/smartlib/controller/SystemController.java
package com.smartlib.controller;

import com.smartlib.common.Result;
import com.smartlib.mapper.BookMapper;
import com.smartlib.mapper.UserMapper;
import com.smartlib.service.BlockchainService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/system")
public class SystemController {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private BookMapper bookMapper;

    @Autowired
    private BlockchainService blockchainService;

    /**
     * 系统健康检查
     * @return
     */
    @GetMapping("/health")
    public Object health() {
        Map<String, Object> health = new HashMap<>();

        try {
            // 数据库健康
            int userCount = userMapper.count();
            int bookCount = bookMapper.selectAll().size();

            // 区块链健康
            boolean blockchainValid = blockchainService.validateChain();
            int blockchainCount = blockchainService.getBlockchain().size();

            health.put("status", "UP");
            health.put("timestamp", System.currentTimeMillis());

            // 修复：不使用 Map.of()，改用传统写法
            Map<String, Object> databaseMap = new HashMap<>();
            databaseMap.put("users", userCount);
            databaseMap.put("books", bookCount);
            databaseMap.put("status", "CONNECTED");
            health.put("database", databaseMap);

            Map<String, Object> blockchainMap = new HashMap<>();
            blockchainMap.put("blocks", blockchainCount);
            blockchainMap.put("valid", blockchainValid);
            blockchainMap.put("status", blockchainValid ? "VALID" : "INVALID");
            health.put("blockchain", blockchainMap);

            health.put("version", "1.0.0");

            return Result.success(health);

        } catch (Exception e) {
            health.put("status", "DOWN");
            health.put("error", e.getMessage());
            Result<Map<String, Object>> result = Result.error("系统异常");
            result.setData(health);
            return result;
        }
    }

    /**
     * 系统信息
     */
    @GetMapping("/info")
    public Result<Map<String, Object>> info() {
        Map<String, Object> info = new HashMap<>();

        info.put("name", "智能图书管理系统");
        info.put("version", "1.0.0");
        info.put("description", "基于区块链的图书共享与推荐系统");
        info.put("developers", new String[]{"组长-A同学", "B同学", "C同学", "D同学", "E同学"});
        info.put("modules", new String[]{
                "用户管理", "图书管理", "区块链交易", "智能推荐", "OCR识别", "学习社区"
        });
        info.put("technology", new String[]{
                "Spring Boot 2.7", "Vue.js 3", "MyBatis", "MySQL", "区块链模拟"
        });
        info.put("timestamp", System.currentTimeMillis());

        return Result.success(info);
    }
}