// src/main/java/com/smartlib/controller/BookController.java
package com.smartlib.controller;

import com.smartlib.common.Result;
import com.smartlib.entity.Book;
import com.smartlib.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/book")
@CrossOrigin(origins = "*")
public class BookController extends BaseController {

    @Autowired
    private BookService bookService;

    @PostMapping("/add")
    public Result<Book> addBook(@RequestBody Book book) {
        try {
            Book addedBook = bookService.addBook(book);
            return Result.success(addedBook);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @PutMapping("/update")
    public Result<Book> updateBook(@RequestBody Book book) {
        try {
            Book updatedBook = bookService.updateBook(book);
            return Result.success(updatedBook);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @DeleteMapping("/delete/{id}")
    public Result<Boolean> deleteBook(@PathVariable Integer id) {
        try {
            boolean success = bookService.deleteBook(id);
            return Result.success(success);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/{id}")
    public Result<Book> getBookById(@PathVariable Integer id) {
        try {
            Book book = bookService.getBookById(id);
            return Result.success(book);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/all")
    public Result<List<Book>> getAllBooks() {
        try {
            List<Book> books = bookService.getAllBooks();
            return Result.success(books);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/search")
    public Result<List<Book>> searchBooks(@RequestParam String keyword) {
        try {
            List<Book> books = bookService.searchBooks(keyword);
            return Result.success(books);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/category/{category}")
    public Result<List<Book>> getBooksByCategory(@PathVariable String category) {
        try {
            List<Book> books = bookService.getBooksByCategory(category);
            return Result.success(books);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @PostMapping("/stock/decrease")
    public Result<Boolean> decreaseStock(
            @RequestParam Integer bookId,
            @RequestParam(defaultValue = "1") Integer quantity) {
        try {
            boolean success = bookService.decreaseStock(bookId, quantity);
            return Result.success(success);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @PostMapping("/stock/increase")
    public Result<Boolean> increaseStock(
            @RequestParam Integer bookId,
            @RequestParam(defaultValue = "1") Integer quantity) {
        try {
            boolean success = bookService.increaseStock(bookId, quantity);
            return Result.success(success);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/popular")
    public Result<List<Book>> getPopularBooks(@RequestParam(defaultValue = "10") Integer limit) {
        try {
            List<Book> books = bookService.getPopularBooks(limit);
            return Result.success(books);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/recommend/{userId}")
    public Result<List<Book>> getRecommendedBooks(@PathVariable Integer userId) {
        try {
            List<Book> books = bookService.getRecommendedBooks(userId);
            return Result.success(books);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }

    @GetMapping("/count")
    public Result<Integer> getBookCount() {
        try {
            List<Book> books = bookService.getAllBooks();
            return Result.success(books.size());
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }
}